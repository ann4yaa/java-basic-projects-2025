/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum5_hagia;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class IfElse_bercabang {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int totalBelanja;
        
        System.out.print("Masukan Total Belanja : ");
        totalBelanja = sc.nextInt();
        
        if (totalBelanja >= 2000000){
            System.out.println("Selamat Anda Mnedapatkan Dorprize Kulkas");
        }
        else if (totalBelanja >= 1000000){
                System.out.println("Selamat Anda Mendapatkan sepeda");
            } else if (totalBelanja >= 500000){
                System.out.println("Selamat Anda Mendapatkan Kompor Gas");
            } else {
                System.out.println("Mohon Maaf Anda Belum Beruntung");
            }
        }
    }
