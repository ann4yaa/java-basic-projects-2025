/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum7_hagia;
//Deklarasi Import
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class NestedIf2 {
     public static void main(String[] args){
        //Deklarasi Variabel Scanner
        Scanner sc = new Scanner(System.in);
       
        String kategori; //deklarasi variabel kategori
        int penghasilan, gajiBersih; //deklarasi variabel penghasilan
        double pajak = 0; //deklarasi variabel pajak
       
        System.out.print("Masukkan Kategori : ");
        kategori = sc.nextLine();
        System.out.print("Masukkan Besarnya Penghasilan : ");
        penghasilan = sc.nextInt();
       
        if (kategori.equalsIgnoreCase ("Pekerja")){
            if (penghasilan <= 2000000) {
                pajak = 0.1;
            } else if (penghasilan <= 3000000){
                pajak = 0.15;
            } else {
                pajak = 0.2;
            }
            gajiBersih = (int) ((penghasilan) - (penghasilan * pajak));
            System.out.println("Gaji bersih yang Anda terima : " + gajiBersih);
        } else if (kategori.equalsIgnoreCase ("Pembisnis")){
            if (penghasilan <= 2500000){
                pajak = 0.15;
            } else if (penghasilan <= 3500000) {
                pajak = 0.2;
            } else {
                pajak = 0.25;
            }
            gajiBersih = (int) ((penghasilan) - (penghasilan * pajak));
            System.out.println("Gaji bersih yang Anda terima : " + gajiBersih);
        } else {
            System.out.println("Kategori Yang Anda Masukkan Salah");
        }
    }
}