/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum5_hagia;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class ifElse {
    public static void main(String[] args){
    Scanner sc = new Scanner(System.in);
    int suhu; //Deklarasi Variabel Suhu
    
    System.out.print("Masukan Suhu Ruangan Anda");
    suhu = sc.nextInt();
    
    if (suhu >= 0 && suhu <= 40){
    if (suhu < 16){
        System.out.println("Gunakan Jaket Anda");
    }
    else{
        System.out.println("Gunakan Topi saja");
    }
    }
    }
}
