/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Soal1;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class Praktikum17_Hagia {
    public static void main(String[] args) {
        //deklarasi variabel
        Scanner sc = new Scanner(System.in);
        double a, b, hitung = 0, choice;
        //deklarasi Input
        System.out.println("=== Kalkulator sederhana ===");
        System.out.println("1. Penjumlahan");
        System.out.println("2. Pengurangan");
        System.out.println("3. Perkalian");
        System.out.println("4. Pembagian");
        System.out.print("\nMasukan pilihan anda (1-4): ");
        choice = sc.nextDouble();
        System.out.print("Masukan Angka ke-1: ");
        a = sc.nextDouble();
        System.out.print("Masukan Angka ke-2: ");
        b = sc.nextDouble();
        //deklarasi pemilihan program
        if (choice == 1){
            hitung = a + b;
        } else if (choice == 2){
            hitung = a - b;
        } else if (choice == 3){
            hitung = a * b;
        } else if (choice == 4){
            hitung = a / b;
        }else {
            System.out.println("Pilihan anda tidak valid!.");
        }
        //hasil perhitungan
        System.out.println("\nHasil perhitungan: "+hitung);
    }
}