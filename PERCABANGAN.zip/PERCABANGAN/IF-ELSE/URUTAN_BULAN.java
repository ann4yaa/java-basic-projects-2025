/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum13_hagia;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class Tugas4_no1 {
    public static void main(String [] args){
        Scanner s = new Scanner(System.in);
        int bulan;
        String [] bln = {"Januari", "Februari", "Maret", "April", "Mey", "Juni", "Juli", "Agustus",
        "September", "Oktober", "November", "Desember"
        };
        System.out.print("Masukan Urutan Bulan: ");
        bulan = s.nextInt();
        
        if (bulan>=1 && bulan <=12){
        System.out.println("Bulan "+bln[bulan -1]);
        }
    }
}
