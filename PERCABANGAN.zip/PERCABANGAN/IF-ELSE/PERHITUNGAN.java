/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package praktikum15_hagia;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class Soal1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        //Deklarasi Variabel
        int a;
        System.out.println("=== Perhitungan ===");
        System.out.println("1. Persegi");
        System.out.println("2. Persegi Panjang");
        System.out.println("3. Lingkaran");
        System.out.print("Berikan pilihan anda: ");
        a = s.nextInt();
        
        if (a == 1) {
            System.out.println("Rumus Luas Persegi");
            System.out.println("L = s * s");
        } else if (a == 2){
            System.out.println("Rumus Luas Perseg Panjang");
            System.out.println("L = p * l");
        } else if (a == 3) {
            System.out.println("Rumus Luas Lingkaran");
            System.out.println("L = 3,14 * r * r");
        }
    } 
}