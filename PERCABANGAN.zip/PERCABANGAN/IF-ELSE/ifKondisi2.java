/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum5_hagia;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class ifKondisi2 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int nilai;
        
        System.out.print("Masukan Hasil Nilai Anda: ");
        nilai = sc.nextInt();
        
        if (nilai > 70){
            System.out.println("Selamat Anda Di Terima Di Perusahaan ini dengan Nilai " + nilai);
        }
}
}
