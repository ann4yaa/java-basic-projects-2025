/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package praktikum5_hagia;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class ifKondisi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int suhu;
        
        System.out.print("Masukan Suhu:");
        suhu = sc.nextInt();
        
        if (suhu < 16){
            System.out.println("Silahkan pakai jaket");
        }
    }
    
}
