/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum5_hagia;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class IfElse2 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int nilai;
        
        System.out.print("Masukan Nilai Anda");
        nilai = sc.nextInt();
        
        if (nilai > 70){
            System.out.println("Selamat Anda Lolos Masuk Perusahaan");
        } else {
            System.out.println("Mohon Maaf Anda Tidak Lolos Seleksi");
        }
    }
    
}
