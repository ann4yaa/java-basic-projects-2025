/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package praktikum7_hagia;
//import library Scanner
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class NestedIf {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int nilai; //Deklarasi variabel nilai 
        
        System.out.print("Masukan Nilai (0 - 100) : ");
        nilai = sc.nextInt();
        
        if(nilai >= 0 && nilai <= 100){
            if(nilai >= 90 && nilai <= 100){
                System.out.println("Nilai A, EXCELLENT!");
            } else if(nilai >= 90 && nilai <= 89){
                System.out.println("Nilai B, ");
            } else if(nilai >= 60 && nilai <=79){
                System.out.println("Nilai C, ");
            } else if(nilai >= 50 && nilai <= 59){
                System.out.println("Nilai D, ");
            } else {
                System.out.println("Nilai E,");
            }
        } else {
                System.out.println("Inputan Tidak Valid. Masukan Angka 0 - 100");
            }
        }
    }
