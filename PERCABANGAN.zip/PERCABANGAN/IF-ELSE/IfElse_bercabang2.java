/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum5_hagia;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class IfElse_bercabang2 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int bayarParkir;
        
        System.out.print("Masukan Harga Pengendara Parkir : ");
        bayarParkir = sc.nextInt();
        
        if (bayarParkir >= 30000) {
            System.out.println("Anda Telah Berparkir Selama 10 Jam");
        } else if (bayarParkir >= 15000){
            System.out.println("Anda Telah Berparkir Selama 5 Jam");
        } else if (bayarParkir >= 5000){
            System.out.println("Anda Telah Berparkir Selama 2 Jam");
        } else {
            System.out.println("Anda Telah Berparkir Kurang dari 1 Jam");
        }
    }
    
}
