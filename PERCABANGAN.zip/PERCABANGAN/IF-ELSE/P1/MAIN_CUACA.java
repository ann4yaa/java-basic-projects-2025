/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package praktikum16_hagia;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class Praktikum16_hagia extends Cuaca{
    double cuaca = 0;
    public static void main(String[] args){
        Scanner s = new Scanner(System.in);
        Cuaca c = new Cuaca();
        
        System.out.print("Masukan suhu anda: ");
        c.cuaca = s.nextDouble();
        c.dataInfo();
    }
    
}
