/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum16_hagia;

/**
 *
 * @author USER
 */
public class Cuaca {
    double cuaca;
    
    public void dataInfo (){
        System.out.println("=== Data Cuaca ===");
        if (cuaca > 1 && cuaca < 40){
            if (cuaca > 1 && cuaca < 20){
                System.out.println("Cuaca sangat dingin");
            } else if (cuaca > 20 && cuaca < 40 ){
                System.out.println("Cuaca sangat panas");
            } else {
                System.out.println("Data tidak valid");
            }
            System.out.println("Cuaca: "+cuaca);
        }
    }
    
}
