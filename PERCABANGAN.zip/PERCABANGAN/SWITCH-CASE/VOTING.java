/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum17_hagia;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class Soal2 {
    public static void main(String [] args){
      Scanner sc = new Scanner(System.in);
      int a=0,b=0;
      String inp;
      System.out.println("==== PROGRAM VOTING OSIS ====");
      System.out.println("Ketik (selesai) untuk mengakhiri");
      
      while(true){
          System.out.print("Masukan pilihan anda (A/B): ");
          inp = sc.nextLine();
          switch (inp){
              case "selesai":
                  break;
              case "A":
                  inp = inp += 1;
                  a++;
                  continue;
              case "B":
                  inp = inp += 1;
                  b++;
                  continue;
          }
          System.out.println("\n---------------------");
          System.out.println("HASIL HITUNG CEPAT");
          System.out.println("Total Suara Kandidat A: "+ a++);
          System.out.println("Total Suara Kandidat B: "+ b++);
          return;
        }
    }
}