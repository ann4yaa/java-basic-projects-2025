/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum7_hagia;
import java.util.Scanner;//Deklarasi Import
/**
 *
 * @author USER
 */
public class kalkulator {
    public static void main(String [] args){
        Scanner sc = new Scanner(System.in);
        //Deklarasi Variabel
        float angka1, angka2, perhitungan;
        char operator; 
        
        //Deklarasi Sistem
        System.out.print("Masukan Angka Pertama: ");
        angka1 = sc.nextFloat();
        System.out.print("Masukan Operator (+, -, *, /): ");
        operator = sc.next().charAt(0);
        System.out.print("Masukan Angka Kedua: ");
        angka2 = sc.nextFloat();
        perhitungan = 0;
        
        //Deklarasi Operator
        switch (operator){
            case '+':
                perhitungan = angka1 + angka2;
                break;
            case '-':
                perhitungan = angka1 - angka2;
                break;
            case '*':
                perhitungan = angka1 * angka2;
                break;
            case '/':
                perhitungan = angka1 / angka2;
                break;
            default:
                System.out.println("Input Anda Tidak Valid");
                return; // keluar dari program
        }
        
        // Hasil Perhitungan
        System.out.println("Hasil Perhitungan Anda: " + angka1 + " " + operator + " " + angka2 + " = " + perhitungan);
    }
}