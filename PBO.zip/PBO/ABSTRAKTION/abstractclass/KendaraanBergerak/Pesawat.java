/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package abstractclass.KendaraanBergerak;

/**
 *
 * @author USER
 */
public class Pesawat extends Kendaraan {
    public Pesawat(){
    super(450, "Avtur");
}
    @Override
    public void bergerak(){
        System.out.println("Pesawat bergerak di Udara, \"wus...wuss\"");
    }
}
