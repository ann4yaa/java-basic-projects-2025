/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package abstractclass.KendaraanBergerak;

/**
 *
 * @author USER
 */
//Abstract
public abstract class Kendaraan {
    protected int kecepatan;
    protected String bahanBakar;

    // Konstruktor
    public Kendaraan(int kecepatan, String bahanBakar) {
        this.kecepatan = kecepatan;
        this.bahanBakar = bahanBakar;
    }

    // Method abstrak
    public abstract void bergerak();

    // Method biasa
    public void keadaan() {
        System.out.println("Kecepatan: " + kecepatan + " Km/Jam");
        System.out.println("Bahan Bakar: " + bahanBakar);
        System.out.println("-----------------------------");
    }
}