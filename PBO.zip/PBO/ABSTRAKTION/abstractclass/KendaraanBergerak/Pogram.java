/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package abstractclass.KendaraanBergerak;

/**
 *
 * @author USER
 */
public class Pogram {
    public static void main(String [] args){
    Mobil mobil = new Mobil();
    Pesawat pesawat = new Pesawat();
    
    mobil.bergerak();
    mobil.keadaan();
    
    pesawat.bergerak();
    pesawat.keadaan();
}
}