/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package abstractclass.KendaraanBergerak;

/**
 *
 * @author USER
 */
public class Mobil extends Kendaraan{
    
   public Mobil(){
        super(320, "Bensin");
    }
    @Override
    public void bergerak(){
        System.out.println("Mobil Bergerak di Jalan Raya, \"Brumm...brumm\"");
    }
}