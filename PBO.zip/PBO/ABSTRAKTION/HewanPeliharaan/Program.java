/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HewanPeliharaan;

/**
 *
 * @author USER
 */
public class Program {
    public static void main(String [] args){
        Kucing kucing = new Kucing();
        Ikan hiu = new Ikan();
        Burung elang = new Burung();
        
        Hewan [] daftarHewan = new Hewan[3];
        
        System.out.println("\n-----Kucing-----");
        for(int i = 0; i<3; i++){
            kucing.bergerak(); 
        }System.out.println("\n-----Ikan-----");
        for(int i = 0; i<3; i++){
            hiu.bergerak();
        }System.out.println("\n-----Burung-----");
        for(int i = 0; i<3; i++){
            elang.bergerak();
        }
    }
}