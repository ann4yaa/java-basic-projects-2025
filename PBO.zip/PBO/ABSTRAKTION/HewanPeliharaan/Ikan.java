/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HewanPeliharaan;

/**
 *
 * @author USER
 */
public class Ikan extends Hewan{
    public void bergerak(){
        System.out.println("Berenang dengan SIRIP, \"Wush...wush\"");
    }
}