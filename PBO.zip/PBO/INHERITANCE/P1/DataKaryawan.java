/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package La;

/**
 *
 * @author USER
 */
public class DataKaryawan{
    public static void main(String [] args){
        Karyawan [] daftar = new Karyawan[3];
        
        daftar[0] = new Karyawan();
        daftar[1] = new KaryawanTetap();
        daftar[2] = new KaryawanMagang();

        for(Karyawan k : daftar){
            k.tampilkanInfo();
        }           
    }
}
