/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package La;

/**
 *
 * @author USER
 */
public class Karyawan {
    void tampilkanInfo(){
        System.out.println("Ini adalah Karyawan Perusahaan.");
    }
}
