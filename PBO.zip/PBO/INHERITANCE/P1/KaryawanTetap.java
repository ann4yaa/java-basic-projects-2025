/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package La;

/**
 *
 * @author USER
 */
public class KaryawanTetap extends Karyawan{
    @Override
    void tampilkanInfo(){
        System.out.println("Ini adalah karyawan dengan gaji bulanan tetap.");
    }
}
