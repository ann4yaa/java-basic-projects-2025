/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inheritance;

/**
 *
 * @author USER
 */
public class Hewan {
    void eat(){
        System.out.println("Hewan bisa makan");
    } 
    void sleep(){
        System.out.println("Hewan bisa tidur");
    }
}
