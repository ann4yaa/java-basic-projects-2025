/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Inheritance;

/**
 *
 * @author USER
 */
public class HewanMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Kucing");
        Kucing k = new Kucing();
        k.eat();
        k.sleep();
        k.meow();
        
        System.out.println("       ");
        
        System.out.println("=== Burung ===");
        Burung b = new Burung();
        b.eat();
        b.sleep();
        b.berkicau();
    }
    
}
