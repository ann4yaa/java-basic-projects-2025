/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inheritance;

/**
 *
 * @author USER
 */
//Parents class
public class ClassA {
    private int x;
    private int y;
    
    public void setX (int x){
        this.x = x;
    }
    public int getX(){
        return this.x;
    }
    public void setY (int y){
        this.y = y;
    }
    public int getY(){
        return this.y;
    }
    
    public void getNilai() {
    System.out.println("Nilai x: " + x);
    System.out.println("Nilai y: " + y);
}
}
