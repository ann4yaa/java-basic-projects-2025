/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Interface;

/**
 *
 * @author USER
 */
public class Cat implements IAnimals{
    @Override
    public void animalSound(){
        System.out.println("grgrgrgrrgrgrgr");
    }
    
    @Override
    public void sleep(){
        System.out.println("Tidurrr");
    }
}
