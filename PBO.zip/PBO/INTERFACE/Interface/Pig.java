/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Interface;

/**
 *
 * @author USER
 */
public class Pig implements IAnimals {
    @Override
    public void animalSound(){
        System.out.println("sssssssss");
    }
    
    @Override
    public void sleep(){
        System.out.println("Tidurrrr");
    }
}
