/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Interface;

/**
 *
 * @author USER
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Pig pig1 = new Pig();
       Cat cat1 = new Cat();
       
       pig1.animalSound();
       pig1.sleep();
       System.out.println("\n");
       cat1.animalSound();
       cat1.sleep();
    }
    
}