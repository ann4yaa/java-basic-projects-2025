/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package IterfaceUML;

/**
 *
 * @author USER
 */
public class Main {
    public static void main(String [] args){
        Keledai keledai = new Keledai("Keledai", "Coklat Emas", "Hiihaa", 4);
        Singa singa = new Singa("Singa", "Coklat Susu", "Roarr", 4);
        Gorila gorila = new Gorila("Gorila", "Hitam Manis", "Haumm", 2);
        
        System.out.println("=== Hewan ===");
        keledai.displayBinatang();
        keledai.displayMakan();
        keledai.displayData();
        System.out.println("\n==========");
        gorila.displayBinatang();
        gorila.displayMakan();
        gorila.displayData();
        System.out.println("\n==========");
        singa.displayBinatang();
        singa.displayMakan();
        singa.displayData();
    }
}
