/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package IterfaceUML;

/**
 *
 * @author USER
 */
class Gorila extends Binatang implements IKarnivora, IHerbivora{
    public Gorila(String nama, String suara, String wrnBl, int jmlhKaki){
        super(nama, suara, wrnBl, jmlhKaki);
    }

    @Override
    public void displayBinatang() {
       System.out.println("Jenis: Karnivora dan Herbivora");
    }

    @Override
    public void displayMakan() {
        System.out.println("Makanan: Daging dan Tumbuhan");
    }
}
