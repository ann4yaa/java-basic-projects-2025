/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package IterfaceUML;

/**
 *
 * @author USER
 */
public abstract class Binatang {
    protected String nama;
    protected int jmlhKaki;
    private String wrnBl;
    private String suara;
    public Binatang(String nama, String wrnBl, String suara, int jmlhKaki){
        this.jmlhKaki = jmlhKaki;
        this.nama = nama;
        this.suara = suara;
        this.wrnBl = wrnBl;
    }
    public void setNama(String nama){
        this.nama = nama;
    }
    public String getNama(){
        return nama;
    }
    public void setjumlahKaki(int jmlhKaki){
        this.jmlhKaki = jmlhKaki;
    }
    public int getjmlhKaki(){
        return jmlhKaki;
    }
    public void displayData(){
        System.out.println("Nama: "+getNama());
        System.out.println("Jumlah Kaki: "+getjmlhKaki());
        System.out.println("Suara: "+suara);
        System.out.println("Warna Bulu: "+wrnBl);
    }
    public abstract void displayBinatang();
}
