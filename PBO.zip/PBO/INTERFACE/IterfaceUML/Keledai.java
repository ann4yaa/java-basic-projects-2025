/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package IterfaceUML;

/**
 *
 * @author USER
 */
class Keledai extends Binatang implements IHerbivora{
    public Keledai(String nama, String suara, String wrnBl, int jmlhKaki){
        super(nama, suara, wrnBl, jmlhKaki);
    }
    

        @Override
        public void displayBinatang() {
            System.out.println("Jenis: Herbivora");
        }

        @Override
        public void displayMakan() {
            System.out.println("Makanan: Tumbuhan");
        }
    }