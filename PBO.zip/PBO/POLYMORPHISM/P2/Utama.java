/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum18_hagia;

import java.awt.Point;

/**
 *
 * @author USER
 */
public class Utama extends SegiEmpat {
     public static void main(String [] args){
            SegiEmpat rect = new SegiEmpat();
            System.out.println("Buat Segi Empat dengan koordinat(25,25) dan (50,50)");
            rect.SegiEmpat(25,25,50,50);
            rect.cetakSegiEpat();
            System.out.println();
            SegiEmpat Rect = new SegiEmpat();
            System.out.println("Buat Segi Empat dengan koordinat(10,10) dan (20,20)");
            rect.SegiEmpat(new Point(10,10),new Point(20,20));
            rect.cetakSegiEpat();
            System.out.println();
            SegiEmpat recT = new SegiEmpat();
            System.out.println("Buat Segi Empat dengan koordinat(10,10) dan (50,50)");
            rect.SegiEmpat(new Point(10,10),new Point(50,50));
            rect.cetakSegiEpat();
    }
}