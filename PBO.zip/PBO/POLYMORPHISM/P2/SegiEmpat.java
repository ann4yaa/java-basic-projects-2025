/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum18_hagia;

import java.awt.Point;

/**
 *
 * @author USER
 */
public class SegiEmpat {
    int x1 = 0;
    int x2 = 0;
    int y1 = 0;
    int y2 = 0;
    
    public void SegiEmpat(int x1, int y1, int x2, int y2){
    this.x1 = x1;
    this.y1 = y1;
    this.x2 = x2;
    this.y2 = y2;
}
    public void SegiEmpat(Point topLeft, Point bottomRight){
        x1=topLeft.x;
        y1=topLeft.y;
        x2=bottomRight.x;
        y2=bottomRight.y;
    }
    public void SegiEmpat(Point topLeft, int w, int h){
        x1=topLeft.x;
        y1=topLeft.y;
        x2=x1+w;
        y2=y1+h;
    }
    public void cetakSegiEpat(){
        System.out.println("Segi Empat <"+x1+","+y1+","+x2+","+y2+">");
    }
    public class Utama{
        public static void main(String [] args){
            SegiEmpat rect = new SegiEmpat();
            System.out.println("Buat Segi Empat dengan koordinat(25,25) dan (50,50)");
            rect.SegiEmpat(25,25,50,50);
            rect.cetakSegiEpat();
            System.out.println();
            System.out.println("Buat Segi Empat dengan koordinat(25,25) dan (50,50)");
            rect.SegiEmpat(10,10,20,20);
            rect.cetakSegiEpat();
            System.out.println();
            System.out.println("Buat Segi Empat dengan koordinat(25,25) dan (50,50)");
            rect.SegiEmpat(10,10,50,50);
            rect.cetakSegiEpat();

        }
    }
}