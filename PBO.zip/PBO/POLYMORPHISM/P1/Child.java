/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum18_hagia;

/**
 *
 * @author USER
 */
public class Child extends ParentsClass{
    public void info(){
        System.out.println("Ini kelas Child.");
    } 
}
