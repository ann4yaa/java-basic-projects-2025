/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum18_hagia;

/**
 *
 * @author USER
 */
public class ChildClass extends ParentsClass{
    public static void main(String [] args){
    public void info(){
            System.out.println("Ini kelas Child.");
    }
}