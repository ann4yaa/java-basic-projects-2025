/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package infocuaca;

/**
 *
 * @author Lab Studio
 */
interface InfoCuaca {
    void dataInfo(String kota, int suhu, String cuaca );
    void tampilDetail();
}
