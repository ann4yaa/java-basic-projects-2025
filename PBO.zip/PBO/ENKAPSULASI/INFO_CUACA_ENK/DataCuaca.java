/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package infocuaca;

/**
 *
 * @author Lab Studio
 */
public class DataCuaca implements InfoCuaca{
    private String kota;
    private int suhu;
    private String cuaca;
    
    public void setKota(String kota){
        this.kota = kota;
    }
    public String getKota(){
        return this.kota;
    }
    public void setSuhu(int suhu){
        this.suhu = suhu;
    }
    public int getSuhu(){
        return this.suhu;
    }
    public void setCuaca(String cuaca){
        this.cuaca = cuaca;
    }
    public String getCuaca(){
        return this.cuaca;
    }
    
    
    @Override
    public void dataInfo(String kota, int suhu, String cuaca) {
        
    }

    @Override
    public void tampilDetail() {
       System.out.println("Kota : " + getKota());
        System.out.println("Suhu : " + getSuhu());
        System.out.println("Cuaca : " + getCuaca());
    }
    
    
}
