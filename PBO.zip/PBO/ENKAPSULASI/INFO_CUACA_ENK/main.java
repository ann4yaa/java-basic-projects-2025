/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package infocuaca;




public class main {
    public static void main (String[]args){
        DataCuaca cuaca = new DataCuaca();
        cuaca.setKota("malang");
        cuaca.setSuhu(29);
        cuaca.setCuaca("cerah");
        
        cuaca.tampilDetail();
    }
}
