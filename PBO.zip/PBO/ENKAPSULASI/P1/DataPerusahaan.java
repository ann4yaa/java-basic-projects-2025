/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Tugas1;

/**
 *
 * @author USER
 */
public class DataPerusahaan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Karyawan k1 = new Karyawan();
        
        k1.setNIP("K001");
        k1.setNama("Wahyu Pratama");
        k1.setDivisi("Marketing");
        k1.info();
    }
}