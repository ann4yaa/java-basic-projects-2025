/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum15_hagia;

/**
 *
 * @author USER
 */
public class Siswa {
    private String nama, jurusan;
    private int nis;
    
    public void setNama(String nama){
        this.nama = nama;
    } 
    public String getNama(){
        return this.nama = nama;
    }
    public void setJurusan(String jurusan){
        this.jurusan = jurusan;
    }
    public String getJurusan(){
        return this.jurusan = jurusan;
    }
    public void setNIS(int nis){
        this.nis = nis;
    }
    public int getNIS(){
        return this.nis = nis;
    }
    public void getInfo(){
        System.out.println("Nama: "+getNama());
        System.out.println("Jurusan: "+getJurusan());
        System.out.println("NIS: "+getNIS());
    }
}
