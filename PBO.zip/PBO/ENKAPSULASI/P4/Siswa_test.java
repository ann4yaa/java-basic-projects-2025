/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum15_hagia;

/**
 *
 * @author USER
 */
public class Siswa_test extends Siswa {
    public static void main(String [] args){
        Siswa s = new Siswa();
        
        s.setNama("Hagia Sofiana");
        s.setJurusan("RPL");
        s.setNIS(2598);
        s.getInfo();
    }
}
