/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PBO;

/**
 *
 * @author USER
 */
public class Hewan {
    private String nama;
    private String habitat;
    private int jumlahKaki;
    
    public void namaHewan(String newValue){
        nama = newValue;
    }
    public void habitaHewan(String newValue){
        habitat = newValue;
    }
    public void totalhKakiHewan(int newValue){
        jumlahKaki = newValue;
    }
    public void cekStatus(){
    System.out.println("Nama Hewan ini: " + nama);
    System.out.println("Habitat Hewan ini: " + habitat);
    System.out.println("Jumlah Kaki Hewan ini: " + jumlahKaki);
    }
}