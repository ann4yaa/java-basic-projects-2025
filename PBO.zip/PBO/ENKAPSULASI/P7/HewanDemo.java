/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PBO;

/**
 *
 * @author USER
 */
public class HewanDemo {
    public static void main(String [] args){
        Hewan hwn1 = new Hewan();
        Hewan hwn2 = new Hewan();
        Hewan hwn3 = new Hewan();
        
        System.out.println("==========");
        hwn1.namaHewan("Jerapah");
        hwn1.totalhKakiHewan(4);
        hwn1.habitaHewan("Darat");
        hwn1.cekStatus();
        System.out.println("==========");
        hwn2.namaHewan("Burung");
        hwn2.totalhKakiHewan(2);
        hwn2.habitaHewan("Darat");
        hwn2.cekStatus();
        System.out.println("==========");
        hwn3.namaHewan("Kucing");
        hwn3.totalhKakiHewan(4);
        hwn3.habitaHewan("Darat");
        hwn3.cekStatus();
    }
}
