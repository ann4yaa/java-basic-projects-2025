/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas2;

/**
 *
 * @author USER
 */
public class DataParkir {
    public static void main(String [] args){
        Kendaraan k1 = new Kendaraan();
        
        k1.setNoPolisi("N 1234 B");
        k1.setMerk("Toyota Avanza");
        k1.setTahun(2022);
        k1.info();
    }
}
