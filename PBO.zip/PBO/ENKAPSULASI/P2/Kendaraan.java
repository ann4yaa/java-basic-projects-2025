/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas2;

/**
 *
 * @author USER
 */
public class Kendaraan {
    private String noPolisi;
    private String merk;
    private int tahun;
    
    public void setNoPolisi (String noPolisi){
        this.noPolisi = noPolisi;
    }
    public String getNoPolisi(){
        return this.noPolisi = noPolisi;
    }
    public void setMerk(String merk){
        this.merk = merk;
    }
    public String getMerk(){
        return this.merk = merk;
    }
    public void setTahun (int tahun){
        this.tahun = tahun;
    }
    public int getTahun(){
        return this.tahun = tahun;
    }
    public void info(){
        System.out.println("=== DATA KENDARAAN ===");
        System.out.println("No. Polisi: "+getNoPolisi());
        System.out.println("Merk: "+getMerk());
        System.out.println("Tahun: "+getTahun());
    }
}