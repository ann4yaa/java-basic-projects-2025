/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PBO;

/**
 *
 * @author USER
 */
public class Siswa {
    private String nama;
    private String nis;
    private double nilaiAkhir;
    
    void setNama (String nama){
        this.nama = nama;
    }
    public String getNama(){
       return this.nama;
    }
    void setNIS (String nis){
        this.nis = nis;
    }
    public String getNIS(){
        return this.nis;
    }
    void setNilaiAkhir(double nilaiAkhir){
        this.nilaiAkhir = nilaiAkhir;
    }
    public double getNilaiAkhir(){
        return this.nilaiAkhir;
    }
    public void tampilData(){
        System.out.println("===== DATA SISWA =====");
        System.out.println("Nama Siswa: " + nama);
        System.out.println("NIS Siswa: " + nis);
        System.out.println("Nilai Akhir Siswa: " + nilaiAkhir);
        
        if (nilaiAkhir >= 90 && nilaiAkhir <= 100){
        System.out.println("Nilai Akhir: A");
    } else if (nilaiAkhir >= 80 && nilaiAkhir <= 89){
        System.out.println("Nilai Akhir: B");
    } else if (nilaiAkhir >= 50 && nilaiAkhir <= 79){
        System.out.println("Nilai Akhir: C");
    } else {
        System.out.println("Nilai Akhir: Tidak Valid (" + nilaiAkhir + ")");
    }
    }
}
