/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PBO;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class SiswaMain {
    public static void main(String [] args){
        Scanner sc = new Scanner(System.in);
        Siswa s = new Siswa();
        
        System.out.print("Masukan Nama Siswa: ");
        String nama = sc.nextLine();
        s.setNama(nama);
        System.out.print("Masukan NIS Siswa: ");
        String nis = sc.nextLine();
        s.setNIS(nis);
        System.out.print("Masukan Nilai Akhir Siswa: ");
        double nilaiAkhir = sc.nextDouble();
        s.setNilaiAkhir(nilaiAkhir);
        
        System.out.println();
        s.tampilData();
    }
}
