/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package engkapsulasi;

/**
 *
 * @author USER
 */
public class mainManager extends manager{
    public static void main(String [] args){
    manager m = new manager();
    
    m.setNama("Melani");
    m.setGajiPokok(2000000);
    m.setTunjangan(500000);
    m.hitungTotal();
}
}