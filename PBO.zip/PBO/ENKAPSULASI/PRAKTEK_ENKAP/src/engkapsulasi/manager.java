/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package engkapsulasi;

/**
 *
 * @author USER
 */
public class manager extends karyawan {
    private double tunjangan;
    private double hitung;
    
    public void setTunjangan(double tunjangan){
        this.tunjangan = tunjangan;
    }
    public double getTunjangan(){
        return tunjangan = tunjangan;
    }
    public void setHitung(double hitung){
        this.hitung = hitung;
    }
    public double getHitung(){
        return hitung = hitung;
    }
    public void hitungTotal(){
        hitung = tunjangan + getGajiPokok();
        System.out.println("Nama: "+getNama());
        System.out.println("Total Gaji: "+hitung);
    }
}