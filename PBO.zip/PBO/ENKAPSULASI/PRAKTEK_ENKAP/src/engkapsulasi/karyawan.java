/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package engkapsulasi;

/**
 *
 * @author USER
 */
public class karyawan {
    private String nama;
    private double gajiPokok;
    
    public void setNama(String nama){
        this.nama = nama;
    }
    public String getNama(){
        return nama = nama;
    }
    public void setGajiPokok(double gajiPokok){
        this.gajiPokok = gajiPokok;
    }
    public double getGajiPokok(){
        return gajiPokok = gajiPokok;
    }
}