/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package remidi;

/**
 *
 * @author USER
 */
public class Singa extends Binatang implements IKarnivora{
    private String suara, warnaBulu;
    
    public Singa (String nama, int jumlahKaki, String suara, String warnaBulu){
    this.jumlahKaki = jumlahKaki;
    this.nama = nama;
    this.suara = suara;
    this.warnaBulu = warnaBulu;
}
    @Override
    public void displayMakan(){
        System.out.println("Jenis: Karnivora");
        System.out.println("Makanan: Tumbuhan");
    }
    @Override
    public void displayBinatang(){
        nama = nama;
        jumlahKaki = jumlahKaki;
        suara = suara;
        warnaBulu = warnaBulu;
        System.out.println("Nama: "+nama);
        System.out.println("Jumlah kaki: "+jumlahKaki);
        System.out.println("Suara: "+suara);
        System.out.println("Warna bulu: "+warnaBulu);
    }
    void displayData(){
        displayMakan();
        displayBinatang();
    }
}
