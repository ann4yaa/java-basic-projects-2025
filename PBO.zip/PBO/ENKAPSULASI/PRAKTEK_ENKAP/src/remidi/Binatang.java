/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package remidi;

/**
 *
 * @author USER
 */
public abstract class Binatang {
    protected String nama;
    protected int jumlahKaki;
    
    void setNama (String nama){
        this.nama = nama;
    }
    public String getNama(){
        return nama;
    }
    void setJumlahKaki (int jumlahKaki){
        this.jumlahKaki = jumlahKaki;
    }
    public int getJumlahKaki(){
        return jumlahKaki;
    }
    public abstract void displayBinatang(); 
}
