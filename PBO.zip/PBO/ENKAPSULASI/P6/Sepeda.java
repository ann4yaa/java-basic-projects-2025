/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PBO;

/**
 *
 * @author USER
 */
public class Sepeda {
    //deklarasi sepeda
    private String merk;
    private int kecepatan;
    private int gear;
    
    //fuction setMerk
    public void setMerk(String newValue){
        merk = newValue;
    }
    public void gantiGear(int newValue){
        gear = newValue;
    }
    public void tambahKecepatan(int increment){ //penambahan
        kecepatan = kecepatan + increment;
    }
    public void kurangiKecepatan(int decrement){//penggurangan
        kecepatan = kecepatan - decrement;
    }
    public void cekStatus(){
        System.out.println("Merek : " + merk);
        System.out.println("Kecepatan : " + kecepatan);
        System.out.println("Gear : " + gear);
    }
}
