/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package PBO;

/**
 *
 * @author USER
 */
public class SepedaDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Sepeda spd1 = new Sepeda();
       
       spd1.setMerk("Poligon");
       spd1.gantiGear(3);
       spd1.tambahKecepatan(40);
       spd1.kurangiKecepatan(20);
       spd1.cekStatus();
    }
    
}
