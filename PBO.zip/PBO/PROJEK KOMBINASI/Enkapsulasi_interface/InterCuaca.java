/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Enkapsulasi_interface;

/**
 *
 * @author USER
 */
interface InterCuaca {
    void suhu();
    void kota();
    void cuaca();
}