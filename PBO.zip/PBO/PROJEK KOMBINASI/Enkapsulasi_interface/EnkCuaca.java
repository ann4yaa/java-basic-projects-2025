/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Enkapsulasi_interface;

/**
 *
 * @author USER
 */
public class EnkCuaca implements InterCuaca{
    private String kota, cuaca;
    private int suhu;
    
    public void setKota(String kota){
        this.kota = kota;
    }
    public String getKota(){
        return this.kota = kota;
    }
    public void setCuaca(String cuaca){
        this.cuaca = cuaca;
    }
    public String getCuaca(){
        return this.cuaca = cuaca;
    }
    public void setSuhu(int suhu){
        this.suhu = suhu;
    }
    public int getSuhu(){
        return this.suhu = suhu;
    }
    @Override
    public void suhu() {
        System.out.println("Jumlah Suhu: "+getSuhu());
    }

    @Override
    public void kota() {
        System.out.println("Nama kota: "+getKota());
    }

    @Override
    public void cuaca() {
        System.out.println("Kondisi Cuaca: "+getCuaca());
    } 
    public void DataInfo(){
        kota();
        cuaca();
        suhu();
    }
}