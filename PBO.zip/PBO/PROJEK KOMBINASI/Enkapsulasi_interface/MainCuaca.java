/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Enkapsulasi_interface;

/**
 *
 * @author USER
 */
public class MainCuaca extends EnkCuaca{
    public static void main(String [] args){
        EnkCuaca c = new EnkCuaca();
        
        c.setKota("Malang");
        c.setCuaca("Dingin");
        c.setSuhu(15);
        c.DataInfo();
    }
}  