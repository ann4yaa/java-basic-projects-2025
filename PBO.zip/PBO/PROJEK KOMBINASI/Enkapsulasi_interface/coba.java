/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Enkapsulasi_interface;

/**
 *
 * @author USER
 */
    import java.util.Scanner;

public class coba {
    // Deklarasi variabel untuk menampung data nilai
    double[] nilai;
    int jumlah;

    // Method untuk menerima input nilai dari pengguna
    public void inputNilai() {
        Scanner input = new Scanner(System.in);

        System.out.print("Masukkan jumlah nilai: ");
        jumlah = input.nextInt();

        nilai = new double[jumlah];

        for (int i = 0; i < jumlah; i++) {
            System.out.print("Masukkan nilai ke-" + (i + 1) + ": ");
            nilai[i] = input.nextDouble();
        }
    }

    // Method untuk menghitung rata-rata
    public void hitungRata() {
        double total = 0;

        for (int i = 0; i < jumlah; i++) {
            total += nilai[i];
        }

        double rata = total / jumlah;
        System.out.println("Rata-rata nilai = " + rata);
    }

    // Method main untuk menjalankan program
    public static void main(String[] args) {
        // Membuat objek dari class Nilai
        coba dataNilai = new coba();

        // Memanggil method inputNilai() dan hitungRata()
        dataNilai.inputNilai();
        dataNilai.hitungRata();
    }
}