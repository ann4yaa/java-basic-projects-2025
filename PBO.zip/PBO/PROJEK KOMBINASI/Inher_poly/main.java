/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inher_poly;

/**
 *
 * @author USER
 */
public class main {
    public static void main(String [] args){
        Mobil m = new Mobil("");
        m.Mobil("BMW", "M4", "Pertamax");
        m.info();
    }
}
