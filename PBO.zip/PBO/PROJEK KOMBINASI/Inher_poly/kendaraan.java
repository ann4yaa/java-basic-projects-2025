/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inher_poly;

/**
 *
 * @author USER
 */
public class kendaraan {
    private String nama;
    public kendaraan(String nama){
        this.nama = nama;
    }
    public void info(){
        
    }
}
