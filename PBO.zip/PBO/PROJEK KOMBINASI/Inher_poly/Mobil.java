/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inher_poly;

/**
 *
 * @author USER
 */
public class Mobil extends kendaraan{
    private String nama, jenis, bhnBkr;

    public Mobil(String nama) {
        super("mobil");
        this.nama = nama;
        jenis = ("belum diketahui");
    }
    public void Mobil (String nama, String jenis, String bhnBkr){
        this.nama = nama;
        this.jenis = jenis;
        this.bhnBkr = bhnBkr;
    }
    public void info(){
        System.out.println("Nama mobil adalah "+nama);
        System.out.println("Jenis mobil adalah "+jenis);
        System.out.println("Bahan Bakar mobil: "+bhnBkr);
    }
}
