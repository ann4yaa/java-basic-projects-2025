/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Perulangan;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class Praktikum_doWhile {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int angka, fac, i;
        System.out.println("=== PROGRAM MENGHITUNG BILANGAN DENGAN MENGGUNAKAN DO WHILE");
        System.out.print("Masukan Bilangan: ");
        angka = sc.nextInt();
        
        fac = 1;
        i = 1;
        do
        {
            fac = fac*i; i++;
        }
        while (i<=angka);
        System.out.printf("Nilai Bilangan Faktorial tsbt adalah: %d \n", fac);
}
}