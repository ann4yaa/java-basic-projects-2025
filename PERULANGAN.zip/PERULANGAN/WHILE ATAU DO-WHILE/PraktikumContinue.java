/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Perulangan;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class PraktikumContinue {
    public static void main(String [] args){
        Scanner s = new Scanner(System.in);
        int angka, b, i , count;
        double avg, total;
        System.out.println("=== PROGRAM LOOP DENGAN CONTINUE PADA FOR ===");
        b = 0;
        count = 0;
        
        for (i=0; i<5; i++){
            System.out.print("Masukan bilangan: ");
            angka = s.nextInt();
            if (angka>=50) continue;
            b += angka;
            count++;
        }
        total = (double)b;
        System.out.printf("Jumlah Angka Kurang dari 50: %.2f \n", total);
        avg = (double)b/count;
        System.out.printf("Rata-rata Angka Kurang dari 50: %.2f \n", avg);
    } 
}