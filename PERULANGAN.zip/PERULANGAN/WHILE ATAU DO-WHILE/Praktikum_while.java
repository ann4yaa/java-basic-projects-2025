/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Perulangan;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class Praktikum_while {
    public static void main (String [] args){
        Scanner sc = new Scanner(System.in);
        int angka, fac, i;
        System.out.println("=== PROGRAM MENGHITUNG BILANGAN FAKTORIAL DENGAN WHILE");
        System.out.print("Masukan bilangan: ");
        angka = sc.nextInt();
        
        fac = 1;
        i = 1;
        
        while(i<=angka){
            fac = fac * i; i++;
        } System.out.printf("Nilai Faktorial dari Bilangan tsb adalah: %d \n", fac);
    }
}
