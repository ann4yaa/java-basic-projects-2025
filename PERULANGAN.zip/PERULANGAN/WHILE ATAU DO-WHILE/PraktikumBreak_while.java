/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Perulangan;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class PraktikumBreak_while {
    public static void main (String [] args){
        Scanner s = new Scanner(System.in);
        int angka, a;
        System.out.println("=== PROGRAM LOOP DENGAN BREAK");
        a = 0;
        while (true){
        System.out.print("Masukan Bilangan: ");
        angka = s.nextInt();
        a += angka;
        if (a>50) break;
        }
        System.out.printf("Angka Berhendi di Bilangan: %d \n", a);
    }
}