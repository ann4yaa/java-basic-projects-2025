/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum17_hagia;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class soal3 {
    public static void main(String []args){
        Scanner s = new Scanner(System.in);
        int y = 1;
        String nama;
        System.out.println("=== PENDAFTARAN ANGGOTA GYM ===");
        
        do {
          System.out.print("Masukkan nama anggota: ");
          nama = s.nextLine();
          System.out.print("Daftar anggota lagi? [ya/tidak]>");
          String daftar = s.nextLine();
          switch (daftar){
            case "tidak":
                System.out.println("Total anggota yang didaftarkan: "+y++);
            break;
            case "ya":
                y++;
                continue;
        } System.out.println("Data nama anggota GYM terakhir: "+nama);
        return;
    }while(true);
}
}