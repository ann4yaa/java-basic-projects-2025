/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Perulangan;
import java.util.Scanner;

/**
 *
 * @author USER
 */
public class Tugas_2 {
    public static void main(String[] args) {
        Scanner i = new Scanner(System.in);
        int n, jumlah, count;

        System.out.println("=== PROGRAM MENGHITUNG BILANGAN GENAP ===");
        System.out.print("Masukkan range bilangan: ");
        n = i.nextInt();

        jumlah = 0;
        count = 0;

        // Hitung jumlah bilangan genap
        for (int x = 1; x <= n; x++) {
            if (x % 2 == 0) {
                count++;
            }
        }

        System.out.println("Banyaknya Bilangan genap dari 1 sampai " + n + " adalah " + count);

        int urutan = 1;
        for (int x = 1; x <= n; x++) {
            if (x % 2 == 0) {
                System.out.println("Bilangan genap Ke-" + urutan + " adalah " + x);
                jumlah += x;
                urutan++;
            }
        }

        double rataRata = (double) jumlah / count;
        System.out.println("Jumlah bilangan genap dari 1 sampai " + n + " = " + jumlah);
        System.out.println("Rata-rata bilangan genap dari 1 sampai " + n + " = " + rataRata);
    }
}