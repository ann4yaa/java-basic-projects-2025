/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Perulangan;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class Tugas_1 {
    public static void main(String [] args){
        Scanner in = new Scanner(System.in);
        int angka, n;
        System.out.println("=== PROGRAM ANGKA BERURUTAN ===");
        System.out.print("Masukan Bilangan: ");
        n = in.nextInt();
        
        for (angka = 1; angka<=n; angka++ ){
            if ( angka %5 == 0) continue;
            System.out.println("Angka: "+angka);
        }
    }
    
}
