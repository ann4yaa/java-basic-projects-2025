/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Perulangan;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class Praktikum_for {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        int angka, fac, i;
        System.out.println("=====PROGRAM MENGHITUNG NILAI FAKTORIAL DENGAN FOR=====");
        System.out.print("Masukan angka: ");
        angka = input.nextInt();
        
        fac =1;
        for (i=1; i<=angka; i++){
            fac = fac*i;
        }
        System.out.printf("Nilai Bilangan Faktorial tersebut adalah: %d \n", fac);
    }
    
}
