/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Perulangan;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class PraktikumBreak_for {
    public static void main(String [] args){
        Scanner sc = new Scanner(System.in);
        
        int angka, i;
        System.out.println("=== PROGRAM LOOP DENGAN BREAK ===");
        for (i=0; true;){
        System.out.print("Masukan Bilangan: ");
        angka = sc.nextInt();
        i += angka;
        
        if (i>50) break;
        }
        System.out.printf("Angka Berhenti pada Angka: %d \n", i);
    }   
}