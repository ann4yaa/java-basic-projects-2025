/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum15_hagia;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class Soal2 {
    public static void main(String [] args){
       Scanner s = new Scanner(System.in);
       //Deklarasi angka
       int angka;
       
       System.out.print("Masukan Angka Anda: ");
       angka = s.nextInt();
       
       for (int i = 1; i < angka; i = i + 2){
           System.out.println("Angka ganjil: "+i);
       }
    }
}