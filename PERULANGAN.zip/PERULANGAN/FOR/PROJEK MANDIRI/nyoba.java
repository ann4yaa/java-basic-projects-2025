/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package latihansndr;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class nyoba {
    public static void main(String [] args){
        Scanner s = new Scanner(System.in);
        
        System.out.print("Masukan jumlah data: ");
        int n = s.nextInt();
        
        int [] nilai = new int[n];
        for (int i = 0; i<n; i++){
            System.out.print("Masukan elemen ke-"+(i+1));
            nilai[i] = s.nextInt();
        }
        System.out.println("\n===");
        for (int i = 0; i<n; i++){
            System.out.println(nilai[i]+" ");
        }
    }
}
