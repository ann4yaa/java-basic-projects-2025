/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum13_hagia;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class Tugas4_no5 {
    public static void main(String [] args){
        Scanner s = new Scanner(System.in);
        int jumlah = 0;
        int [] array = new int[8];
        
        for (int i = 0; i<8; i++){
            System.out.print("Masukan Angka Geometri: ");
            array[i] = s.nextInt();
            jumlah += array[i];
        }
        System.out.println("Jumlah suku: "+jumlah);
    }
}
