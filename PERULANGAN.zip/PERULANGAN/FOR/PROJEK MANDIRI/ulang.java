/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package latihansndr;

/**
 *
 * @author USER
 */
public class ulang {
    public static void main(String [] args){
        for(int i = 0; i<3; i++){
            for(int j = 0; i<2; j++){
                System.out.print("*");
            }
        }
    }
}
