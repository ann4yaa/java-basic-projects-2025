/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package latihansndr;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class perulanganhitung {
    public static void main(String [] args){
        Scanner s = new Scanner(System.in);
        
        System.out.print("Masukan Bilangan: ");
        int n = s.nextInt();
        for (int i = 0; i < n; i++){
            int fac = n*i*n;
        System.out.println(""+n);
        System.out.println(fac);
        }
    }
}