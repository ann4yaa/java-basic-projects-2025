/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package latihansndr;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class Penggulangan {
    public static void main(String [] args){
        Scanner s = new Scanner(System.in);
        
        System.out.print("Masukan Bilangan: ");
        int n = s.nextInt();
        
        for (int i = 1; i < n; i++){
            if ( i % 2 == 0){
                System.out.println("Angka "+i+": Genap");
            }else if (i % 2 == 1){
                System.out.println("Angka "+i+": Ganjil");
            } 
        }
    }
}
