/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package latihansndr;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class DataNilai {
    public static void main(String [] args){
        Scanner s = new Scanner(System.in);
        int data, total=0, nR, nT, rata;
        
        System.out.print("Masukan Data: ");
        data = s.nextInt();
        int [] nilai = new int[data];
        for(int i = 0; i<nilai.length; i++){
            System.out.print("Nilai ke-"+(i+1)+": ");
            nilai[i] = s.nextInt();
        }
        nT = nilai[0];
        nR = nilai[0];
        for(int i = 0; i<nilai.length; i++){
            total += nilai[i];
            if(nilai[i] > nT){
                nT = nilai[i];
            }
            if(nilai[i] < nR){
                nR = nilai[i];
            }
        }
        rata = total / nilai.length;
        System.out.println("Tinggi: "+nT);
        System.out.println("Rendah: "+nR);
        System.out.println("rata: "+rata);
    }
}