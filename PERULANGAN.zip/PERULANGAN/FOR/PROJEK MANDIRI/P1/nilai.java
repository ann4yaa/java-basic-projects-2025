/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package latihansndr;

/**
 *
 * @author USER
 */
public class nilai {
    int tambah(int a, int b){
        return a+b;
    }
}
