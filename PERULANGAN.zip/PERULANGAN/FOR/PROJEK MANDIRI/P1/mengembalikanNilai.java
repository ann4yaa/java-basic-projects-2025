/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package latihansndr;

/**
 *
 * @author USER
 */
public class mengembalikanNilai {
    public static void main(String [] args){
        
        nilai n = new nilai();
        System.out.println(n.tambah(9, 3));
    }
}
