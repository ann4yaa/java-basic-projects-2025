/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum13_hagia;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class Tugas4_no2 {
    public static void main(String [] args){
        Scanner s = new Scanner(System.in);
        int [] elemen = new int [5];
        
        for (int i=0; i<5; i++){
            System.out.print("Masukan elemen ke- "+(i+1)+": ");
            elemen[i] = s.nextInt();
        }
        for (int i = 0; i < elemen.length; i++){
            System.out.println("Elemen ke-"+ (i+1)+": "+elemen[elemen.length -1 - i]);
        }
    }
}