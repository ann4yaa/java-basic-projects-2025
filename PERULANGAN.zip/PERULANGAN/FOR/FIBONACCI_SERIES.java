/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Perulangan;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class Tugas_3 {
    public static void main(String [] args){
        Scanner s = new Scanner(System.in);
        
        int a = 0, b = 1, c, d, x;
        System.out.println("=== PROGRAM FIBONACCI ===");
        System.out.print("Masukkan bilangan: ");
        d = s.nextInt();
        
        System.out.println("\nFibonacci Series");
        System.out.print(a + " " + b + " ");
        
        for (x = 2; x < d; x++){
            c = a + b;
            System.out.print(c+" ");
            a = b;
            b = c;
        }
        a = 0;
        b = 1;
        
        System.out.println("\n");
        for (x = 2; x <= d; x++){
            c = a + b;
            System.out.println("Sum of: " + a + " + " + b + " = " + c);
            a = b;
            b = c;
        }
    }
}
