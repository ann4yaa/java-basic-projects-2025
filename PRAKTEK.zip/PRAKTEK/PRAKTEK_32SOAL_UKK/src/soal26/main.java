/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal26;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class main {
    public static void main(String [] args){
        Scanner s = new Scanner(System.in);
        Cuaca c = new Cuaca();
        
        System.out.print("Masukan suhu: ");
        c.cuaca = s.nextInt();
        c.tampilkanPrediksi();
    }
}
