/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal26;

/**
 *
 * @author USER
 */
public class Cuaca {
    double cuaca;
    public void tampilkanPrediksi(){
        System.out.println("==== Data Cuaca ===");
        if (cuaca > 1 && cuaca < 40){
            if (cuaca > 1 && cuaca < 15){
                System.out.println("Cuaca sangat dingin");
            } else if (cuaca > 15 && cuaca < 25){
                System.out.println("Cuaca hangat");
            } else if (cuaca > 25 && cuaca < 40){
                System.out.println("Cuaca sangat panas");
            } else {
                System.out.println("Input tidak valid");
            }
        }System.out.println("Cuaca: "+cuaca);
    }
}
