/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal9;

/**
 *
 * @author USER
 */
public class main {
    public static void main(String [] args){
        CashPayment c = new CashPayment();
        DigitalPayment d = new DigitalPayment();
        c.makePayment(90000);
        c.printReceipt();
        
        d.makePayment(890000);
        d.printReceipt();
    }
}
