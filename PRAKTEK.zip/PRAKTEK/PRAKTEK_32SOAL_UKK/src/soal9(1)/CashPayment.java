/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal9;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class CashPayment implements Payable{
    Scanner s = new Scanner(System.in);
    int jumlah, totalBayar, uangDiterima, kembalian;
    @Override
    public void makePayment(double amount){
        System.out.print("Masukan harga: ");
        amount = s.nextInt();
        System.out.print("Masukan jumlah barang: ");
        jumlah = s.nextInt();
        System.out.println("Masukan jumlah uang:");
        uangDiterima = s.nextInt();
        totalBayar = (int) (amount * jumlah);
        kembalian = uangDiterima - totalBayar;
    }
    @Override
    public void printReceipt(){
        System.out.println("Total Bayar: "+totalBayar);
        System.out.println("Uang Diterima: "+uangDiterima);
        System.out.println("Kembalian: "+kembalian);
    }
}
