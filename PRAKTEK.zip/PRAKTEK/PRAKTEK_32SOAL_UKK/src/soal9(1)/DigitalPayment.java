/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal9;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class DigitalPayment implements Payable{
    Scanner s = new Scanner(System.in);
    String namaApk;
    int total;
    @Override
    public void makePayment(double amount) {
        System.out.print("Masukan nama Apl Pembayaran: ");
        namaApk = s.nextLine();
        System.out.print("Masukan Jumlah Nominal: ");
        total = s.nextInt();
    }
    @Override
    public void printReceipt() {
        System.out.println("Nama Aplikasi Pembayaran: "+namaApk);
        System.out.println("Jumlah Nominal yang Dibayarkan: "+total);
    }
}