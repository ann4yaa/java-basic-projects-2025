/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package soal9;

/**
 *
 * @author USER
 */
public interface Payable {
    void makePayment(double amount);
    void printReceipt();
}
