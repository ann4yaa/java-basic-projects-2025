/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal13;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class soal13 {
    public static void main(String [] args){
        Scanner s = new Scanner(System.in);
        int angka, ganjil = 0 , genap = 1;
        System.out.print("Masukan Angka: ");
        angka = s.nextInt();
        System.out.println("Bilangan Ganjil");
        for(int i = 1; i<angka; i = i+2){
            System.out.println(i);
            ganjil +=i;
        }
        System.out.println("Bilangan Genap");
        for(int i = 0; i<angka; i = i+2){
            System.out.println(i);
            genap +=i;
        }
        System.out.println("=== Hasil ===");
        System.out.println("Total Bilangan Ganjil: "+ganjil);
        System.out.println("Total Bilangan Genap: "+genap);
    }
}