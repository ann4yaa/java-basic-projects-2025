/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal6;

/**
 *
 * @author USER
 */
public class main {
    public static void main(String [] args){
        Mahasiswa m1 = new Mahasiswa();
        
        m1.setNama("Rara");
        m1.setNim(87657);
        m1.setNilai(90);
        m1.tampilkanInfo();
    }
}