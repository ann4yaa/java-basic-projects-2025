/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal6;

/**
 *
 * @author USER
 */
public class Mahasiswa {
    private String nama;
    private int nim;
    private int nilai;
    
    public void setNama(String nama){
        this.nama = nama;
    }
    public String getNama(){
        return nama;
    }
     public void setNim(int nim){
        this.nim = nim;
    }
    public int getNim(){
        return nim;
    }
     public void setNilai(int nilai){
        this.nilai = nilai;
    }
    public int getNilai(){
        return nilai;
    }
    
    public void tampilkanInfo(){
        System.out.println("=== Data Mahasiswa ===");
        System.out.println("Nama Mahasiswa: "+getNama());
        System.out.println("Nim Mahasiswa: "+getNim());
        System.out.println("Nilai Mahasiswa: "+getNilai());
    }
}