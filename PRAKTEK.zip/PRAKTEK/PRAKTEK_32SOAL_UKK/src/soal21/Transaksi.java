/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package soal21;

/**
 *
 * @author USER
 */
public interface Transaksi {
    void tarik(int jumlah);
    void setor(int jumlah);
}
