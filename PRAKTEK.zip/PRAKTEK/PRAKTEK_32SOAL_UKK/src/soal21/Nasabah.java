/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal21;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class Nasabah implements Transaksi{
    Scanner s = new Scanner(System.in);
    private String nama;
    private int saldo;
    public void Nasabah(String nama, int saldo){
        this.nama = nama;
        this.saldo = saldo;
    }
    @Override
    public void setor(int jumlah) {
      saldo += jumlah;
      System.out.println(nama+"Menyetor: "+jumlah);
    }

    @Override
    public void tarik(int jumlah) {
        System.out.println(nama+"Menarik: " +jumlah); 
    } public String getNama(){
        return nama;
    }
    public int getSaldo(){
        return saldo;
    }
}