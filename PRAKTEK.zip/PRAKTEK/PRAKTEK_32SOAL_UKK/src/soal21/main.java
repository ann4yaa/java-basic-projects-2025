/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal21;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class main {
    public static void main(String [] args){
        Scanner s = new Scanner (System.in);
        Nasabah n = new Nasabah();
        n.Nasabah("hagia", 900000);
        n.setor(200000);
        n.tarik(100000);

        System.out.println("\n=== Ringkasan Transaksi ===");
        System.out.println("Nama Nasabah: " + n.getNama());
        System.out.println("Saldo Akhir: Rp" + n.getSaldo());
    }
}