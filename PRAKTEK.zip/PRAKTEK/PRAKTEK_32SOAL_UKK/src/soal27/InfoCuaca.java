/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package soal27;

/**
 *
 * @author USER
 */
public interface InfoCuaca {
    void dataInfo(String kota, int suhu, String cuaca );
    void tampilDetail();
}
