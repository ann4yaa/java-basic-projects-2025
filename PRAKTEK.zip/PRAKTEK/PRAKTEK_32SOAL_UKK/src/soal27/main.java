/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal27;

/**
 *
 * @author USER
 */
public class main {
    public static void main(String [] args){
        DataCuaca c = new DataCuaca();
        
        c.DataCuaca("Dingin", "Malang", 20);
        c.tampilDetail();
    }
}
