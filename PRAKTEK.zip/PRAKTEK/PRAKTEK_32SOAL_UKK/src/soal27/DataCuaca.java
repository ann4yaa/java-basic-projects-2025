/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal27;

/**
 *
 * @author USER
 */
public class DataCuaca implements InfoCuaca{
    private String cuaca;
    private int suhu;
    private String kota;
    public void DataCuaca(String cuaca, String kota, int suhu){
    this.cuaca = cuaca;
    this.kota = kota;
    this.suhu = suhu;
}
    public String getCuaca(){
        return cuaca;
    }
    public String getKota(){
        return kota;
    }
    public int getSuhu(){
        return suhu;
    }
    @Override
    public void dataInfo(String kota, int suhu, String cuaca) {
        
    }

    @Override
    public void tampilDetail() {
        System.out.println("Kota : " + getKota());
        System.out.println("Suhu : " + getSuhu());
        System.out.println("Cuaca : " + getCuaca());
    }
    
}
