/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal30;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class NilaiSiswa {
    public static void main(String [] args){
    Scanner s = new Scanner(System.in);
    
    int nilai;
    System.out.println("=== Data Nilai Siswa ===");
    System.out.print("Masukan Nilai Siswa: ");
    nilai = s.nextInt();
    
    System.out.println("Nilai Siswa: "+nilai);
    if (nilai > 90 && nilai < 100){
        System.out.println("Grade A");
        }else if (nilai > 80 && nilai < 90){
            System.out.println("Grade B");
        } else if (nilai > 75 && nilai < 80){
            System.out.println("Grade C");
        } else if (nilai > 60 && nilai < 75){
            System.out.println("Grade D");
        } else {
            System.out.println("Grade E");
        }
    }
}