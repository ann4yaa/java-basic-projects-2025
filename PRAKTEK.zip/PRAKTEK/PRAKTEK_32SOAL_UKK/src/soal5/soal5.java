/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal5;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class soal5 {
    public static double hitungRata(int[] nilai) {
        int total = 0;
        for (int n : nilai) {
            total += n;
        }
        return (double) total / nilai.length;
    }

    // Prosedur untuk menampilkan status kelulusan
    public static void tampilkanStatus(double rata) {
        System.out.println("Rata-rata Nilai: " + rata);
        if (rata >= 70) {
            System.out.println("Status: Lulus");
        } else {
            System.out.println("Status: Tidak Lulus");
        }
    }

    // Fungsi utama
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] nilai = new int[5];

        System.out.println("Masukkan 5 nilai ujian:");
        for (int i = 0; i < nilai.length; i++) {
            System.out.print("Nilai ke-" + (i + 1) + ": ");
            nilai[i] = input.nextInt();
        }

        double rataRata = hitungRata(nilai);
        tampilkanStatus(rataRata);
    }
}