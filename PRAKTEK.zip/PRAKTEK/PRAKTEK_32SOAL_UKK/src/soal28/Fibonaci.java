/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal28;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class Fibonaci {
    public static void main(String [] args){
        Scanner s = new Scanner(System.in);
        int a = 0, b = 1, c;

        System.out.println("=== PROGRAM FIBONACCI ===");
        System.out.print("Masukan jumlah n: ");
        int n = s.nextInt();

        int x = 1; 
        System.out.println("\nDeret Fibonacci:");
        System.out.print(a + " ");

        while (x < n) { 
            System.out.print(b + " ");
            c = a + b;
            a = b;
            b = c;
            x++;
        }
    }
}