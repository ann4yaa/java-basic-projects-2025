/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal23;

/**
 *
 * @author USER
 */
public class main extends soal23{
    public static void main(String [] args){
    int [] nilai = {75, 60, 90, 83, 55};
    int tertinggi = nTinggi(nilai);
    int terendah = nRendah(nilai);
    
    System.out.println("Nilai Tertinggi: "+tertinggi);
    System.out.println("Nilai Terendah: "+terendah);
    }
}
