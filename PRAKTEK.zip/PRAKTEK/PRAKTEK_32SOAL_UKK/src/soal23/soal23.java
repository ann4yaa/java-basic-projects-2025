/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal23;

/**
 *
 * @author USER
 */
public class soal23 {
    public static int nTinggi(int [] data){
        int max = data[0];
        for (int i = 0; i < data.length; i++){
            if (data[i]>max){
                max = data[i];
            }
        }
        return max;
    }
    public static int nRendah(int [] data){
        int min = data[0];
        for (int i = 1; i < data.length; i++){
            if (data[i] < min){
                min = data[i];
            }
        }
        return min;
    }
}