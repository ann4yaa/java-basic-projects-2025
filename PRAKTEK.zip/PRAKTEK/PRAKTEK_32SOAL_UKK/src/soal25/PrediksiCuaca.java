/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal25;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class PrediksiCuaca {
    public static void main(String [] args){
       Scanner s = new Scanner(System.in);
       int suhu;
       String cuaca;
       
       System.out.print("Masukan suhu ruangan: ");
       suhu = s.nextInt();
       
       if (suhu > 1 && suhu < 40)
           if (suhu > 1 && suhu < 15){
            System.out.println("Suhu Ruangan Dingin");
        } else if (suhu > 15 && suhu < 25){
            System.out.println("Suhu Ruangan Hangat");
        } else if (suhu > 25 && suhu < 40){
            System.out.println("Suhu Ruangan Panas");
        } else {
            System.out.println("Input Tidak valid");
        }
    }
}