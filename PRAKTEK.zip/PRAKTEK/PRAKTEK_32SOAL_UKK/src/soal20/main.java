/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal20;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class main {
    public static void main(String [] args){
       Nasabah n = new Nasabah("yya", 90000);
       n.setorUang(50000);
       n.tarikUang(45000);
        
        System.out.println("\n=== Ringkasan Transaksi ===");
        System.out.println("Nama Nasabah: " + n.getNama());
        System.out.println("Saldo Akhir: Rp" + n.getSaldo());
    }
}
