/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal20;

/**
 *
 * @author USER
 */
public class Nasabah {
    protected String nama;
    protected double saldo;
    
    public Nasabah(String nama, double saldo){
        this.nama = nama;
        this.saldo = saldo;
    }
    public void setorUang(int setor) {
        saldo += setor;
        System.out.println(nama + " Menyetor: "+ setor);
    }
    public void tarikUang(int tarik) {
        if (tarik <= saldo) {
            saldo -= tarik;
            System.out.println(nama+" Menarik: "+tarik);
        } else {
            System.out.println("Saldo tidak cukup!");
        }
    } public String getNama(){
        return nama;
    }
    public double getSaldo(){
        return saldo;
    }
}