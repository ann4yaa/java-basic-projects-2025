/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package soal1;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class Soal1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int pilihan;
        String namaBarang;
        double harga = 0, jumlah, total, diskon = 0, totalAkhir;

        System.out.println("=== Kasir Mini Market ===");
        System.out.println("Daftar Produk:");
        System.out.println("1. Kaos - Rp152.000");
        System.out.println("2. Sweater - Rp198.000");
        System.out.println("3. Celana Panjang - Rp225.000");
        System.out.println("4. Celana Pendek - Rp145.000");
        System.out.println("5. Jaket - Rp340.000");

        System.out.print("Masukkan nomor produk (1-5): ");
        pilihan = s.nextInt();

        if (pilihan == 1) {
            namaBarang = "Kaos";
            harga = 152000;
        } else if (pilihan == 2) {
            namaBarang = "Sweater";
            harga = 198000;
        } else if (pilihan == 3) {
            namaBarang = "Celana Panjang";
            harga = 225000;
        } else if (pilihan == 4) {
            namaBarang = "Celana Pendek";
            harga = 145000;
        } else if (pilihan == 5) {
            namaBarang = "Jaket";
            harga = 340000;
        } else {
            System.out.println("Pilihan tidak valid.");
            return;
        }

        System.out.print("Masukkan jumlah barang: ");
        jumlah = s.nextDouble();

        total = harga * jumlah;

        if (total > 400000) {
            diskon = 0.35;
        } else if (total > 250000) {
            diskon = 0.25;
        } else {
            diskon = 0.10;
        }

        totalAkhir = total - (total * diskon);

        System.out.println("\n=== Struk Belanja ===");
        System.out.println("Nama Barang       : " + namaBarang);
        System.out.println("Jumlah Barang     : " + (int) jumlah);
        System.out.println("Total Sebelum Diskon : Rp" + total);
        System.out.println("Diskon Diberikan  : " + diskon + "%");
        System.out.println("Total Bayar Akhir : Rp" + totalAkhir);
    }
}