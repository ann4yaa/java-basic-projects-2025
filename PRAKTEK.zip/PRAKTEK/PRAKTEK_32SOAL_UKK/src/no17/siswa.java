/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package no17;

/**
 *
 * @author USER
 */
public class siswa extends Nilai{
    public static void main(String [] args){
        Nilai n = new Nilai ();
        n.inputNilai();
        n.hitungRataRata();
    }
}
