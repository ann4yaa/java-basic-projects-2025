/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package no17;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class Nilai {
    Scanner s = new Scanner(System.in);
    int nilai, jumlah;
    double rataRata, total = 0;
    void inputNilai(){
        System.out.print("Masukan jumlah Nilai: ");
        jumlah = s.nextInt();
        
        for (int i = 0; i < jumlah; i++){
        System.out.print("Masukan Nilai Mahasiswa ke-"+(i+1)+":");
        nilai = s.nextInt();
        total += nilai;
        }
    }
    void hitungRataRata(){
        rataRata = total/jumlah;
        total = rataRata;
        System.out.println("Nilai siswa: "+nilai);
        System.out.println("Rata-Rata: "+rataRata);
    }
}