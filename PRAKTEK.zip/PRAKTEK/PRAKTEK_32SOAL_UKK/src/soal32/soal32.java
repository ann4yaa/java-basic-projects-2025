/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal32;

/**
 *
 * @author USER
 */
public class soal32 {
    public static void main(String [] args){
        String [] siswa = {"Alexa", "Deby", "Hagia", "Marsya", "Melani", "Michelle"};
        for (int i = 0; i < siswa.length; i++){
            System.out.println((i+1)+". "+siswa[i]);
        }
        System.out.println("\n");
        for(int i = siswa.length - 1; i > 0; i--){
            System.out.println((siswa.length-i)+".  "+siswa[i]);
        }
    }
}