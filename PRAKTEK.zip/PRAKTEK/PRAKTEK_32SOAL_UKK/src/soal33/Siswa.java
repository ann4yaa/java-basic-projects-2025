/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal33;

/**
 *
 * @author USER
 */
public class Siswa {
    String nama;
    int kelas;
    void tampilkanNama(String nama){
        this.nama = nama;
    }
    public String getNama(){
        return nama;
    }
    void tampilkanKelas(int kelas){
        this.kelas = kelas;
    }
    public int getKelas(){
        return kelas;
    }
    public void tampil(){
        System.out.println("Nama Siswa: "+getNama());
        System.out.println("Kelas: "+getKelas());
    }
}
