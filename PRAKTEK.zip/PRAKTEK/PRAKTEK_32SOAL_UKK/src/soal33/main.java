/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal33;

/**
 *
 * @author USER
 */
public class main {
    public static void main(String [] args){
        Siswa s = new Siswa();
        s.tampilkanNama("Hagia");
        s.tampilkanKelas(10);
        s.tampil();
    }
}
