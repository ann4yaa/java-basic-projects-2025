/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal29;

/**
 *
 * @author USER
 */
public class Fibonacci {
    public static int F (int n){
        if (n == 0){
            return 0;
        } else if (n == 1){
            return 1;
        } else {
            return F (n-1)+ F(n-2);
        }
    }
    public static void main(String [] args){
        int n = 23;
        int hasil = F(n);
        
        System.out.println("Nilai Fibonacci ke-"+n+": "+hasil);
    }
}
