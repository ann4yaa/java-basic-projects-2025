/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal14;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class main {
    public static void main(String [] args){
    Scanner s = new Scanner(System.in);
    Prima p = new Prima();
    int n;
    
    System.out.print("Masukan Jumlah Bilangan: ");
    int prim = s.nextInt();
    for (int i = 0; i<prim; i++){
    System.out.print("Masukan Bilangan ke-" +(i+1)+": ");
    n = s.nextInt();
    if(p.cekPrima(n)){
        System.out.println(n+" adalah Bilangan Prima");
        } else {
        System.out.println(n+" bukan Bilangan Prima");
            }
        }
    }
}