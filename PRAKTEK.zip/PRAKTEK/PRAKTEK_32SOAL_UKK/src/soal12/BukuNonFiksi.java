/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal12;

/**
 *
 * @author USER
 */
public class BukuNonFiksi extends Buku implements Interface{
    @Override
    public double hitungBonus(){
        return getHarga() * 0.05;
    }
    @Override 
    public void tampilkanInfo(){
        System.out.println("Diskon: "+hitungBonus());
        System.out.println("Harga setelah diskon: "+(getHarga()- hitungBonus()));
        super.tampilkanInfo();
    }
}