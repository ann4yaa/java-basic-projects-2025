/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal12;

/**
 *
 * @author USER
 */
public class main {
    public static void main(String [] args){
        BukuFiksi fiksi = new BukuFiksi();
        System.out.println("=== Buku Fiksi ===");
        fiksi.setJudul("Laskar Pelangi");
        fiksi.setPenulis("Andrea Hirata");
        fiksi.setHarga(80000);
        fiksi.tampilkanInfo();

        System.out.println("\n=== Buku Non Fiksi ===");
        BukuNonFiksi nonFiksi = new BukuNonFiksi();
        nonFiksi.setJudul("Belajar Java");
        nonFiksi.setPenulis("Yaya");
        nonFiksi.setHarga(100000);
        nonFiksi.tampilkanInfo();
    }
}
