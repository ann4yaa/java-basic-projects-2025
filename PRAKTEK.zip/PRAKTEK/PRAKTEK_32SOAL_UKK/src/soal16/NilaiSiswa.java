/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal16;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class NilaiSiswa {
    public static void main(String [] args){
        Scanner sc = new Scanner(System.in);
        int jumlahSiswa = 0;
        int jumlahMapel = 0;
        System.out.print("Masukan Jumlah Siswa: ");
        jumlahSiswa = sc.nextInt();
        System.out.print("Masukan Jumlah Mapel: ");
        jumlahMapel = sc.nextInt();
        int[][] nilai = new int[jumlahSiswa][jumlahMapel];
        for (int i = 0; i < jumlahSiswa; i++){
            System.out.println("=== Nilai Siswa ke-"+(i+1)+" ===");
            for (int j = 0; j < jumlahMapel; j++){
                System.out.print("Masukan Nilai Mapel ke-"+(j+1)+": ");
                nilai[i][j] = sc.nextInt();
            } 
        } 
            System.out.println("\n=== DATA NILAI SISWA ===");
        for (int i = 0; i<jumlahSiswa; i++){
            int total = 0;
            System.out.println("Nilai siswa ke-"+(i+1)+": ");
            for (int j = 0; j < jumlahMapel; j++){
            System.out.println(nilai[i][j]+ " ");
            total += nilai[i][j];
            }
            double rataRata = (double) total / jumlahMapel;
            System.out.println("Rata - Rata Siswa ke-"+(i+1)+": "+rataRata);
        }
    }
}