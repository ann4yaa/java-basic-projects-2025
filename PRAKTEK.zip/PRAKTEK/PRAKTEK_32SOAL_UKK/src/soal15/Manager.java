/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal15;

/**
 *
 * @author USER
 */
public class Manager extends Karyawan{
    private int tunjangan;
    public void Manager(int tunjangan){
        this.tunjangan = tunjangan;
    }
    public int getTunjangan(){
        return tunjangan;
    }
    public void hitungTotalGaji(){
        int total = getGajiPokok() + getTunjangan();
        System.out.println("Nama: "+getNama());
        System.out.println("Gaji Pokok: "+getGajiPokok());
        System.out.println("Total Gaji: "+total);
    }
}