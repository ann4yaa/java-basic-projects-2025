/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal15;

/**
 *
 * @author USER
 */
public class Karyawan {
    private String nama;
    private int gajiPokok;
    
    public void Karyawan(String nama, int gajiPokok){
        this.nama = nama;
        this.gajiPokok = gajiPokok;
    }
    public String getNama(){
        return nama;
    }
    public int getGajiPokok(){
        return gajiPokok;
    }
}
