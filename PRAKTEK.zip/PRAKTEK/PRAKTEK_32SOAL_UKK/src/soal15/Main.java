/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal15;

/**
 *
 * @author USER
 */
public class Main {
    public static void main(String [] args){
        Manager m = new Manager();
        
        m.Karyawan("rara", 3500000);
        m.Manager(500000);
        m.hitungTotalGaji();
    }
}
