/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal18.main;
import soal18.data.Nilai;
/**
 *
 * @author USER
 */
public class Main {
    public static void main(String [] args){
        Nilai n = new Nilai();
        
        n.Nilai(90);
        System.out.println("Nilai: "+n.getNilai());
    }
}