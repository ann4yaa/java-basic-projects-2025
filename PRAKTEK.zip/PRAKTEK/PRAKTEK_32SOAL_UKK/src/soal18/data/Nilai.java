/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal18.data;

/**
 *
 * @author USER
 */
public class Nilai {
    private int nilai;
    public void Nilai(int nilai){
        this.nilai = nilai;
    }
    public int getNilai(){
        return nilai;
    }
}
