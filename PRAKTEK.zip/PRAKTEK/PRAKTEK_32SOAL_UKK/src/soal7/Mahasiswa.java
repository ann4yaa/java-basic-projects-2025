/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal7;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class Mahasiswa {
    public static void main(String [] args){
        Scanner s = new Scanner(System.in);
        System.out.print("Masukkan jumlah mahasiswa: ");
        int jumlah = s.nextInt();
        s.nextLine(); // membersihkan newline

        String[] nama = new String[jumlah];
        int[] nilai = new int[jumlah];

        for (int i = 0; i < jumlah; i++) {
            System.out.println("\nMahasiswa ke-" + (i + 1));
            System.out.print("Nama: ");
            nama[i] = s.nextLine();

            System.out.print("Nilai (0–100): ");
            nilai[i] = s.nextInt();
            s.nextLine(); // bersihkan newline
        }

        System.out.println("\n=== Daftar Nilai Mahasiswa ===");
        for (int i = 0; i < jumlah; i++) {
            String status;
            char grade;

            // Penentuan status kelulusan
            if (nilai[i] >= 60) {
                status = "Lulus";
            } else {
                status = "Tidak Lulus";
            }

            // Penentuan nilai huruf
            switch (nilai[i] / 10) {
                case 10:
                case 9:
                    grade = 'A';
                    break;
                case 8:
                    grade = 'B';
                    break;
                case 7:
                    grade = 'C';
                    break;
                case 6:
                    grade = 'D';
                    break;
                default:
                    grade = 'E';
            }

            // Output hasil
            System.out.println("Nama: " + nama[i]);
            System.out.println("Nilai: " + nilai[i]);
            System.out.println("Nilai Huruf: " + grade);
            System.out.println("Status: " + status);
            System.out.println("---------------------------");
        }
    }
}