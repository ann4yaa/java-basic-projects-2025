/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal3;

/**
 *
 * @author USER
 */
public class Main {
    public static void main(String [] args){
        Kasir k1 = new Kasir();
        Gudang g1 = new Gudang();
        
        k1.Kasir("andin", 2000000, 430000);
        k1.tampilkanData();
        System.out.println("\n");
        g1.Gudang("Tata", 1500000, 320000);
        g1.tampilkanData();
    }
}