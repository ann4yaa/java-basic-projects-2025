/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal3;

/**
 *
 * @author USER
 */
public class Pegawai {
    protected String nama;
    protected double gajiPokok;
    
    public void Pegawai (String nama, double gajiPokok){
        this.nama = nama;
        this.gajiPokok = gajiPokok;
    }
    public void tampilkanData(){
        System.out.println("Nama Pegawai: "+nama);
        System.out.println("Gaji Pokok pegawai: Rp"+gajiPokok);
    }
    
}
