/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal3;

/**
 *
 * @author USER
 */
public class Kasir extends Pegawai{
    private double bonus;
    
    public void Kasir(String nama, int gajiPokok, int bonus){
        this.nama = nama;
        this.gajiPokok = gajiPokok;
        this.bonus = bonus;
    }
    @Override
    public void tampilkanData(){
        System.out.println("Nama Pegawai Kasir: "+nama);
        System.out.println("Gaji Pokok Pegawai: "+gajiPokok);
        System.out.println("Bonus: "+bonus);
        System.out.println("Total Gaji: "+(bonus+gajiPokok));
    }
}