/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal34;

/**
 *
 * @author USER
 */
public class Orang {
    private String nama;
    void Orang(String nama){
        this.nama = nama;
    }
    public String getNama(){
        return nama;
    }
}
