/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal34;

/**
 *
 * @author USER
 */
public class Siswa extends Orang{
    private String kelas;
    void Siswa(String kelas){
        this.kelas = kelas;
    }
    public String getKelas(){
        return kelas;
    }
    public void tampil(){
        System.out.println("Nama Siswa: "+getNama());
        System.out.println("Kelas Siswa: "+getKelas());
    }
}
