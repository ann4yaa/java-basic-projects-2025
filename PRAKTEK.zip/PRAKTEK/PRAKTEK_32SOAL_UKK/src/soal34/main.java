/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal34;

/**
 *
 * @author USER
 */
public class main {
    public static void main(String [] args){
        Siswa s = new Siswa();
        
        s.Orang("Hagia");
        s.Siswa("X-RPB");
        s.tampil();
    }
}
