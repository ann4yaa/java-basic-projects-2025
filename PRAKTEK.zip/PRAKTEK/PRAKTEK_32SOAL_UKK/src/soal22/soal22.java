/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal22;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class soal22 {
    public static void main(String [] args){
        Scanner s = new Scanner(System.in);
        double n, rataRata, nTinggi, nRendah, total = 0;

        System.out.print("Masukan data nilai anda: ");
        int a = s.nextInt();
        int [] nilai = new int[a];
        for (int i = 0; i < nilai.length; i++){
            System.out.print("Masukan nilai ke-"+(i+1)+":");
            nilai[i] = s.nextInt();
        }nTinggi = nilai[0];
        nRendah = nilai [0];
            for (int i = 0; i<nilai.length; i++){
                total += nilai[i];
                if (nilai[i]>nTinggi){
                    nTinggi = nilai[i];
                }
                if (nilai[i] < nRendah){
                    nRendah = nilai[i];
            }
        }  rataRata = total / nilai.length;
        System.out.println("Rata Rata Nilai: " + rataRata);
        System.out.println("Nilai Tertinggi: " + nTinggi);
        System.out.println("Nilai Terendah: " + nRendah);
    }
}