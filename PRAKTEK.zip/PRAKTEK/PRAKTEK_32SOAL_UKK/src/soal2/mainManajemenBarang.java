/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal2;

/**
 *
 * @author USER
 */
public class mainManajemenBarang {
    public static void main(String [] args){
        Barang b = new Barang();
        b.setNama("kemeja");
        b.setHarga(345000);
        b.setStok(4);
        b.tambahStok();
        b.kurangiStok();
        b.tampilkanInfo();
    }
}