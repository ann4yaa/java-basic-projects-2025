/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal2;

/**
 *
 * @author USER
 */
public class Barang {
    String nama;
    int harga=0, stok=0;
    
    public void setNama (String nama){
        this.nama = nama;
    }
    public String getNama(){
        return this.nama = nama;
    }
    public void setHarga (int harga){
        this.harga = harga;
    }
    public int getHarga(){
        return this.harga = harga;
    }
    public void setStok (int stok){
        this.stok = stok;
    }
    public int getStok(){
        return this.stok = stok;
    }
    public void tambahStok(){
        stok++;
    } public void kurangiStok(){
        if (stok < 0)
        stok--;
    }
    public void tampilkanInfo(){
        System.out.println("=== Manajemen Barang ===");
        System.out.println("Nama Barang: "+getNama());
        System.out.println("Harga Barang: "+getHarga());
        System.out.println("Stok: "+getStok());
    }
}