/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal19;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class ATM {
    public static void main(String [] args){
        Scanner s = new Scanner(System.in);
        //Deklarasi Variabe
        int choice;
        int [] saldo = {0,0,0,0};
        System.out.println("Masukan no urut nasabah (0-3)");
        int nasabah = s.nextInt();
        System.out.println("=== ATM ===");
        System.out.println("1. Cek Saldo");
        System.out.println("2. Tarik Uang");
        System.out.println("3. Setor Uang");
        System.out.println("4. Keluar");
        System.out.print("Masukan pilihan (1/2/3/4): ");
        choice = s.nextInt();
        
        switch (choice){
            case 1:
                System.out.println("Saldo anda: Rp"+saldo[nasabah]);
                break;
            case 2:
                System.out.print("Nominal uang yang ditarik: Rp"+saldo);
                int tarik = s.nextInt();
                if (tarik < saldo[nasabah]){
                    saldo[nasabah] -= tarik;
                    System.out.println("Tarik Berhasil. Saldo sekarang: Rp"+saldo[nasabah]);
                } else {
                System.out.println("Gagal Transaksi anda, Saldo kurang!");
                }
                break;
            case 3:
                System.out.print("Masukan jumlah setor uang: Rp");
                int setor = s.nextInt();
                saldo[nasabah] += setor;
                System.out.println("Setor berhasil. Saldo anda: Rp"+saldo[nasabah]);
            case 4:
                System.out.println("Keluar!");
            default:
                return;
        }
    }
}