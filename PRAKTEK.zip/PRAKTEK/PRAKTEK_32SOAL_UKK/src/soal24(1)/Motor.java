/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal24;

/**
 *
 * @author USER
 */
public class Motor extends Kendaraan{
    private String nama;
    private String jenis;
    private String bhanBkr;
    
    public Motor(String nama){
        super("motor");
        this.nama = nama;
    }

    public Motor(String nama, String jenis, String bhanBkr) {
        super("motor");
        this.nama = nama;
        this.jenis = jenis;
        this.bhanBkr = bhanBkr;
    }
    public void info(){
        System.out.println("Nama motor adalah "+nama);
        System.out.println("Jenis motor adalah "+jenis);
        System.out.println("Bahan Bakar motor: "+bhanBkr);
    }
}
