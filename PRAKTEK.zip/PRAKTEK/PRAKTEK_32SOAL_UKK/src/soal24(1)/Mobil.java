/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal24;

/**
 *
 * @author USER
 */
public class Mobil extends Kendaraan{
    private String nama;
    private String jenis;
    private String bhanBkr;
    public Mobil(String nama) {
        super("mobil");
        this.nama = nama;
        jenis = "belum teridentifikasi";
    }
    public Mobil (String nama, String jenis, String bhanBkr){
        super("mobil");
        this.nama = nama;
        this.jenis = jenis;
        this.bhanBkr = bhanBkr;
    }
    public void info(){
        System.out.println("Nama mobil adalah "+nama);
        System.out.println("Jenis mobil adalah "+jenis);
        System.out.println("Bahan Bakar mobil: "+bhanBkr);
    }
}