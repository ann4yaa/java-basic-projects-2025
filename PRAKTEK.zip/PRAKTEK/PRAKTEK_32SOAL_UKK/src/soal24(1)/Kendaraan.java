/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal24;

/**
 *
 * @author USER
 */
public class Kendaraan {
    private String model;
    public Kendaraan(String model){
        this.model = model;
    }
    public void info(){
        
    }
}
