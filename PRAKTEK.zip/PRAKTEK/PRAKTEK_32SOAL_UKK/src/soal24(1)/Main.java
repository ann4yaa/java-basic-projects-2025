/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal24;

/**
 *
 * @author USER
 */
public class Main {
    public static void main(String [] args){
        Mobil m = new Mobil("BMW", "M4", "Pertamax Turbo");
        Motor mt = new Motor("Vario", "125", "Pertamax");
        
        mt.info();
        System.out.println("\n");
        m.info();
    }
}
