/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal11;

/**
 *
 * @author USER
 */
public class main {
   public static void main(String [] args){
       Buku b1 = new Buku();
       Buku b2 = new Buku();
       
       b1.setJudul("Cinderella");
       b1.setPenulis("gatau");
       b1.setHarga(35000);
       b1.tampilkanInfo();
       System.out.println("\n");
       b2.setJudul("Cinderella");
       b2.setPenulis("gatau");
       b2.setHarga(35000);
       b2.tampilkanInfo();
   } 
}
