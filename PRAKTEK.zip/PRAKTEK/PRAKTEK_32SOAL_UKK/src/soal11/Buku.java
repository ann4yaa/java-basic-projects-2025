/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal11;

/**
 *
 * @author USER
 */
public class Buku {
    private String judul, penulis;
    private int harga;
    
    void setJudul(String judul){
        this.judul = judul;
    }
    public String getJudul(){
        return judul;
    }
    void setPenulis(String penulis){
        this.penulis = penulis;
    }
    public String getPenulis(){
        return penulis;
    }
    void setHarga(int harga){
        this.harga = harga;
    }
    public int getHarga(){
        return harga;
    }
    void tampilkanInfo(){
        System.out.println("Judul Buku: "+getJudul());
        System.out.println("Penulis Buku: "+getPenulis());
        System.out.println("Harga Buku: "+getHarga());
    }
}