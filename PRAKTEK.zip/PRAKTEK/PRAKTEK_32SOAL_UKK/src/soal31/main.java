/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal31;

/**
 *
 * @author USER
 */
public class main {
    public static void main(String [] args){
        Penilaian s = new Penilaian();
        
        s.Penilaian(98, 94, 87);
        s.hitungNilaiAkhir();
    }
}
