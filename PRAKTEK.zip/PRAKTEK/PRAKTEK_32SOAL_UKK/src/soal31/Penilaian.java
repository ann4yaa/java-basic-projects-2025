/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal31;

/**
 *
 * @author USER
 */
public class Penilaian implements IEvaluasi{
    private double nilaiTugas;
    private double nilaiUTS;
    private double nilaiUAS;
    
    void Penilaian(double nilaiTugas, double nilaiUTS, double nilaiUAS){
        this.nilaiTugas = nilaiTugas;
        this.nilaiUAS = nilaiUAS;
        this.nilaiUTS = nilaiUTS;
    }
    public double getNilaiTugas(){
        return nilaiTugas;
    }
    public double getNilaiUTS(){
        return nilaiUTS;
    }
    public double getNilaiUAS(){
        return nilaiUAS;
    }

    @Override
    public void hitungNilaiAkhir() {
        double hitung = (nilaiTugas + nilaiUAS + nilaiUTS);
        double total = hitung / 3;
        System.out.println("Nilai Tugas: "+getNilaiTugas());
        System.out.println("Nilai UTS: "+getNilaiUTS());
        System.out.println("Nilai UAS: "+getNilaiUAS());
        System.out.println("Total Nilai Akhir Siswa: "+total);
    }
}
