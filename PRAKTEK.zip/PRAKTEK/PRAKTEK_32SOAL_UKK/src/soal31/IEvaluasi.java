/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package soal31;

/**
 *
 * @author USER
 */
public interface IEvaluasi {
    void hitungNilaiAkhir();
}
