/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal8.employee;
import soal8.employee.management.SalaryManager;
import soal8.employee.Employee;
/**
 *
 * @author USER
 */
public class main{
    public static void main(String[] args) {
        Employee emp = new Employee();
        SalaryManager sm = new SalaryManager();

        emp.setNama("Rara");
        emp.setJabatan("staff");

        sm.setGajiPokok(5000000);

        emp.tampilkanData();
        sm.calculateBonus(emp.getJabatan());
    }
}