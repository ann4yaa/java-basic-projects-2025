/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal8.employee.management;
import soal8.employee.Employee;
/**
 *
 * @author USER
 */
public class SalaryManager extends Employee{
    private int gajiPokok;
    private double bonus;
    private double totalGaji;

    public void setGajiPokok(int gajiPokok) {
        this.gajiPokok = gajiPokok;
    }

    public int getGajiPokok() {
        return gajiPokok;
    }

    public double getBonus() {
        return bonus;
    }

    public double getTotalGaji() {
        return totalGaji;
    }
    public void calculateBonus(String jabatan) {
        if (jabatan.equals("staff")) {
            bonus = 0.10 * gajiPokok;
        } else if (jabatan.equals("manager")) {
            bonus = 0.20 * gajiPokok;
        } else {
            bonus = 0;
        }

        totalGaji = gajiPokok + bonus;

        System.out.println("Gaji Pokok: " + gajiPokok);
        System.out.println("Bonus: " + bonus);
        System.out.println("Total Gaji: " + totalGaji);
    }
}