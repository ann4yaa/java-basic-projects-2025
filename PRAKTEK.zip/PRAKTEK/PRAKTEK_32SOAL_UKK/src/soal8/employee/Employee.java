/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal8.employee;
import soal8.employee.management.SalaryManager;
/**
 *
 * @author USER
 */
public class Employee {
    private String nama;
    private String jabatan;

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNama() {
        return nama;
    }

    public void setJabatan(String jabatan) {
        this.jabatan = jabatan;
    }
    public String getJabatan() {
        return jabatan;
    }

    public void tampilkanData() {
        System.out.println("Nama Karyawan: " + nama);
        System.out.println("Jabatan: " + jabatan);
    }
}