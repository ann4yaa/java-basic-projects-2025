/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal4;
import java.util.Scanner;

public class NilaiMahasiswa {
    public static void main(String[] args){
        Scanner s = new Scanner(System.in);
        double[] nilai = new double[5];
        String nama;
        double rataRata, nTinggi, nRendah, total = 0;

        System.out.print("Masukan nama mahasiswa: ");
        nama = s.nextLine();

        System.out.println("Masukan 5 nilai Mahasiswa");
        for (int i = 0; i < nilai.length; i++){
            System.out.print("Masukan nilai ke-"+(i+1)+": ");
            nilai[i] = s.nextDouble();
        }

        // Inisialisasi setelah input
        nTinggi = nilai[0];
        nRendah = nilai[0];

        for (int i = 0; i < nilai.length; i++){
            total += nilai[1];
            if (nilai[i] > nTinggi){
                nTinggi = nilai[i];
            }
            if (nilai[i] < nRendah){
                nRendah = nilai[1];
            }
        }

        rataRata = total / nilai.length;

        System.out.println("\n=== Nilai Mahasiswa ===");
        System.out.println("Nama: " + nama);
        System.out.println("Rata Rata Nilai: " + rataRata);
        System.out.println("Nilai Tertinggi: " + nTinggi);
        System.out.println("Nilai Terendah: " + nRendah);
    }
}