/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal10;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class DataBuku {
    public static void main(String [] args){

        Buku [] daftarBuku = new Buku [3];
        daftarBuku [0] = new Buku("Cinderella", "gatau", 89000 );
        daftarBuku [1] = new Buku("Doraemon", "gatau", 80000 );
        daftarBuku [2] = new Buku("Marsya and the bear", "gatau", 98000 );
        
        System.out.println("=== DAFTAR BUKU ===");
        for (int i = 0; i < daftarBuku.length; i++){
            daftarBuku[i].tampilkanData();
        }
        Buku bMahal = daftarBuku[0];
        for (int i = 1; i<daftarBuku.length; i++){
            if (daftarBuku[i].harga > bMahal.harga){
                bMahal = daftarBuku[i];
            }
        } System.out.println("\nBuku Termahal: ");
        bMahal.tampilkanData();
    }
}