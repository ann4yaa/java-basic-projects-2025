/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soal10;

/**
 *
 * @author USER
 */
public class Buku {
    String judul, penulis;
    int harga;
    Buku(String judul, String penulis, int harga){
        this.judul = judul;
        this.penulis = penulis;
        this.harga = harga;
    }
    public void tampilkanData(){
        System.out.println("Judul: " + judul); 
        System.out.println("Penulis: " + penulis); 
        System.out.println("Harga: Rp" + harga);
    }
}