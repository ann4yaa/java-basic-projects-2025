/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package praktikum3_hagia;

/**
 *
 * @author USER
 */
public class Praktikum3_Hagia {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    // Operator Aritmatika
    System.out.println("Operator Aritmatika");
    int a = 20, b = 42;
    System.out.println(a+b); //Penambahan
    System.out.println(a-b); //Penggurangan
    System.out.println(a/b); //Pembagian
    System.out.println(a*b); //Perkalian
    System.out.println(a%b); //Sisa bagi
        
    //Operator Increment dan Decrement
    System.out.println("Operator Increment dan Decrement");
    int jumlahBarang = 7;
    System.out.println(++jumlahBarang); // Menaikan 1 nilai int
    System.out.println(--jumlahBarang); // Menurunkan 1 nilai int
    
    //Operator Assignment
    System.out.println("Operator Assigment");
    int produksi = 30, hari= 7;
    System.out.println(produksi);
    produksi += hari; // Pengisian dan penambahan
    System.out.println(produksi);
    produksi -= hari; //Pengisian dan pengurangan
    System.out.println(produksi);
    produksi *= hari; // Pengisian dan perkalian
    System.out.println(produksi);
    produksi /= hari; //Pengisian dan pembagian
    System.out.println(produksi);
    produksi %= hari; //pengisian dan sisa bagi
    System.out.println(produksi); //hasil terakhir
    
    //Operator Relasi
    System.out.println("Operator Relasi");
    int tinggi_tiang = 250, lebar = 150;
    //Menentukan Trus or False, tergantung dari data 
    System.out.println(tinggi_tiang > lebar); //Bernilai True
    System.out.println(tinggi_tiang < lebar); //Bernilai False
    System.out.println(tinggi_tiang == lebar); //Bernilai False
    System.out.println(tinggi_tiang != lebar); //Bernilai True
    System.out.println(tinggi_tiang >= lebar); //Bernilai True
    System.out.println(tinggi_tiang <= lebar); //Bernuilai False
    
    //Operator Logika
    System.out.println("Operator Logika");
    boolean tinggi = true, pendek = false;
    System.out.println(tinggi && pendek); //hasilnya false
    System.out.println(tinggi || pendek); //hasilnya true
    System.out.println(!tinggi); //hasilnya false
    }
    
}