/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Ujian_kamis16;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class TugasPraktek1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;
        System.out.println("=== Bilangan Ganjil dan Genap");
        System.out.print("Masukan Batas Angka: ");
        n = sc.nextInt();
        
        for (int x = 1; x <= n; x++){
            if ( x % 2 == 0){
                System.out.println(x +"  " + "adalah Genap");
            }
            else {
                System.out.println(x +"  " + "adalah Ganjil");
            }
    }
    
  }
}