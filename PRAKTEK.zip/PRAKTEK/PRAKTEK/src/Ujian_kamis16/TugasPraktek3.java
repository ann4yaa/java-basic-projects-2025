/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ujian_kamis16;
import java.util.Scanner;

public class TugasPraktek3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int siswa, grade;

        System.out.print("Masukkan jumlah siswa: ");
        siswa = sc.nextInt();

        for (int x = 0; x < siswa; x++) {
            System.out.print("Nilai siswa ke-" + (x + 1) + ": ");
            grade = sc.nextInt();

            System.out.print("Nilai huruf: ");
            if (grade >= 90 && grade <= 100) {
                System.out.println("A");
            } else if (grade >= 80 && grade <= 89) {
                System.out.println("B");
            } else if (grade >= 70 && grade <= 79) {
                System.out.println("C");
            } else if (grade >= 60 && grade <= 69) {
                System.out.println("D");
            } else {
                System.out.println("E");
            }
        }
    }
}