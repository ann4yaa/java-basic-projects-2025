/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ujian_kamis16;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class TugasPraktek2 {
    public static void main(String [] args){
        Scanner sc = new Scanner(System.in);
        double totalBayar = 0, totalBelanja = 0, diskon = 0, hargaBarang;
        System.out.println("=== Belanja ===");
         
        while (true){
            System.out.print("Masukan harga barang (0 untuk selesai)");
            hargaBarang = sc.nextInt();
            
            if (hargaBarang == 0){
            break;
        } totalBelanja += hargaBarang;
        }
        if (totalBelanja >= 100000){
                diskon = totalBelanja * 0.10;
                
        System.out.println("Total Belanja: "+ totalBelanja);
        
                System.out.println("Anda mendapat diskon 10%");
        } else {
                System.out.println("Anda tidak mendapat diskon");
        }
        totalBayar = totalBelanja-diskon;
        System.out.println("Total Bayar: " + totalBayar);
    } 
}