/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum2_hagia;

import java.util.Scanner; // import package scnner untuk inputan
/**
 *
 * @author USER
 */
public class Praktikum_Input {
    public static void main(String[] args) {
        //Deklarasi variaber scanner(sc)
        Scanner sc = new Scanner(System.in);
        String nama;
        System.out.print("Masukan nama mu: "); 
        nama = sc.next();

        String kelas;
        System.out.print("Masukan kelas mu: "); 
        kelas = sc.next();

        int usia;
        // Deklarasi variabel usia
        System.out.print("Masukan usia mu: "); 
        usia = sc.nextInt();
        
        System.out.println("=== HASIL INPUTAN PENGGUNA ===");
        System.out.println("Nama kamu adalah " + nama);
        System.out.println("Kelas anda adalah " + kelas);
        System.out.println("Usia Anda adalah " + usia);
    }
}
