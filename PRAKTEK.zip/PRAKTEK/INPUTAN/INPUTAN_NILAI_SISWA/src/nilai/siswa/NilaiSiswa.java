/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package nilai.siswa;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class NilaiSiswa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        int agama, bIndo, bInggris, mTK, ipa, rataRata, total, jumlahMapel;
        
        jumlahMapel = 5;
        System.out.println("Masukan jumlah nilai agama");
        agama = sc.nextInt ();
        System.out.println("Masukan jumlah nilai Bahasa indonesia");
        bIndo = sc.nextInt ();
        System.out.println("Masukan jumlah nilai Bahasa inggris");
        bInggris = sc.nextInt();
        System.out.println("Masukan jumlah nilai Matematika");
        mTK = sc.nextInt();
        System.out.println("Masukan jumlah nilai IPA");
        ipa = sc.nextInt();
        total = agama + bIndo + bInggris + mTK + ipa;
        
        rataRata = jumlahMapel / total;
        System.out.println("================");
        System.out.println("Total nilai: " + total);
        System.out.println("Jumlah Rata-Rata: " + rataRata);
        
        if (rataRata >= 70){
            System.out.println("Keterangan: Lulus");
            }else{
            System.out.println("Keterangan : Tidak lulus");
        }
    }
    
}
