/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package praktikum2_hagia;

import java.util.Scanner; // untuk memasukkan input an
/**
 *
 * @author USER
 */
public class Praktikum2_Hagia {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int bilangan; //(bulat)
        byte contohBilanganByte; 
        float volume, luas; // 2 variabel dalam satu tipe data yang sama (desimal)
        int angka = 1; // nilai awal dengan 1 data yang tidak dapat berubah kecuali di panggi untuk perulangan
        float phi = 3.14f; // di tambah dengan huruf f guna untuk mengetahui bahwa itu bertipe data float
        char kelas = 'X'; // hanya menyimpan 1 karakter dengan tanda petik 1
        String nama = "Hagia Sofiana";
        String jurusan = "-RPLB";
        
        System.out.println("=== OUTPUT ===");
        System.out.println("Nilai Angka = " + angka);
        System.out.println("Nama Saya adalah " + nama);
        System.out.println("Saya Kelas " + kelas + jurusan);
    }
}
