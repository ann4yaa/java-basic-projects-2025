/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum3_hagia;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class luas_segitiga {
    public static void main(String[] args){
      Scanner input = new Scanner(System.in); // deklarasi variabel scanner
      int alas , tinggi; //deklarasi
      float luas;
      System.out.print("Masukan Alas: ");
      alas = input.nextInt ();
      System.out.print("Masukan Tinggi: ");
      tinggi = input.nextInt();
      luas = (alas * tinggi)/ 2;
      System.out.println("===== HASIL LUAS SEGITIGA =====");
      System.out.println("Luas Segitiga = " + luas);
}
}