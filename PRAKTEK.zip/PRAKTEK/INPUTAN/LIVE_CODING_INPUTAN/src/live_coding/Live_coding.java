/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package live_coding;

import java.util.Scanner;
/**
 *
 * @author USER 
 */
public class Live_coding {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        
        int panjang;
        System.out.print("Masukan jumlah panjang!...");
        panjang = sc.nextInt();
        
        int lebar;
        System.out.print("Masukan jumlah lebar!...");
        lebar = sc.nextInt();
        
        int hasil = panjang * lebar;
        
        System.out.println("Jumlah Panjang adalah: " + panjang);
        System.out.println("Jumlah Lebar adalah: " + lebar);
        System.out.println("Hasilnya adalah: " + hasil);
    }
    
}
