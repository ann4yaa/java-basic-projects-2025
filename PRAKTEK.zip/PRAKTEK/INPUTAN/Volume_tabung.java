/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum3_hagia;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class Volume_tabung {
    public static void main(String[] args){
      Scanner input = new Scanner(System.in); // Deklarasi variabel Scanner
      float jari, tinggi; // Deklarasi variabel jari-jari dan tinggi
      double phi = 3.14; // Deklarasi variabel phi dengan 3.14
      float volume; //Deklarasi variabel volume
      
      System.out.print("Masukan jari-jari: "); //Perintah untuk memasukkan jari-jari
      jari = input.nextInt(); //Menyimpan inputan jari-jari
      System.out.print("Masukan Tinggi: "); //Perintah untuk memasukan tinggi
      tinggi = input.nextInt(); //Menyimpan inputan tinggi
      volume = (float) (phi*jari*tinggi); //Melakukan perhitungan untuk menghasilkan jumlah volume
      System.out.println("===== HASIL VOLUME TABUNG =====");
      System.out.println("Volume Tabung = " + volume); //Hasil volume yang di hitung
}
}
