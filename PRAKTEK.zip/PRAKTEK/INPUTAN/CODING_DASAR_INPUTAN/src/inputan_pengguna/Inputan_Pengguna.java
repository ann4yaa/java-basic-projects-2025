/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package inputan_pengguna;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class Inputan_Pengguna {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Siapa nama kamu? ");
        String nama = sc.nextLine();

        System.out.print("Apa jurusan kamu sekarang? ");
        String jurusan = sc.nextLine();

        System.out.print("Apa alasan kamu masuk di jurusan ini? ");
        String alasanMasukJurusan = sc.nextLine();

        System.out.print("Apa cita-cita kamu? ");
        String pekerjaanImpian = sc.nextLine();

        System.out.println("\n=== HASIL INPUTAN PENGGUNA ===");
        System.out.println("Nama kamu adalah " + nama);
        System.out.println("Jurusan kamu adalah " + jurusan);
        System.out.println("Jadi alasan kamu masuk jurusan ini adalah " + alasanMasukJurusan);
        System.out.println("Pekerjaan impian kamu adalah " + pekerjaanImpian);
    }
    
}
