/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Array;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class array {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int [] bill = new int [5];
        
        for (int i=0; i<5; i++){
            System.out.print("Masukan Bilangan ke "+ i + ":");
            bill[i] = sc.nextInt();
        }
        for (int i=0; i<5; i++){
            System.out.println("Isi Bilangan ke "+ i + "adalah :" + bill[i]);
        }
    }
}