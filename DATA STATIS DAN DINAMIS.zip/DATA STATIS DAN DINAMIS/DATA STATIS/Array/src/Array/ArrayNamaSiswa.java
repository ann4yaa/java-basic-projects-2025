/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Array;

/**
 *
 * @author USER
 */
public class ArrayNamaSiswa {
    public static void main(String [] args){
        
        String [] nama = {
            "Akbar", "Alexa", "Ananda", "Ardan", "Axzefa", "Azril",
            "Brian", "Deby","Emory","Galih","Hagia","Nasuha","Marsya",
            "Maulana","Melani","Michele","Orva","Athif","Hilman","Haekal",
            "Rahardian","Richard","Ridwan","Riendra","Nafis","Kevin","Natan","Zidane",
            "Zharif","Zaki","Zaskia","Tegar"
        };
        for (int i=0; i<nama.length; i++){
            System.out.println("Siswa Absen ke-" + (i + 1) + ": " + nama[i]);
            }
        } 
    } 