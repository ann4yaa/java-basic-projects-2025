/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package latihansndr;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class Array1 {

    private static int n;
    public static void main(String [] args){
        Scanner s = new Scanner(System.in);
        System.out.print("Masukan Jumlah Siswa: ");
        int jumlah = s.nextInt();
        
        int total = 0;
        int max = 0;
        int min = 0;
        
        int [] nilai = new int[jumlah];
        for(int i = 0; i < jumlah; i++){
            System.out.print("Nilai Siswa ke-"+(i+1)+": ");
            nilai[i] = s.nextInt();
            
            nilai[i] += total;
            
            if(nilai[i] > max) max = nilai[i];
            if(nilai[i] < min) min = nilai[1];
        }
        double rR = (double) total / jumlah;
        System.out.println("\n=== HASIL ===");
        System.out.print("Daftar nilai: ");
        for (int n : nilai) {
            System.out.print(n + " ");
        }

        System.out.println("\nNilai tertinggi : " + max);
        System.out.println("Nilai terendah   : " + min);
        System.out.println("Rata-rata nilai  : " + rR);
    }  
}
