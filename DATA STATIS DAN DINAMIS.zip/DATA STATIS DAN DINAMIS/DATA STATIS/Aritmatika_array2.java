/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum13_hagia;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class Aritmatika_array2 {
    public static void main(String [] args){
        Scanner sc = new Scanner(System.in);
        int [] siswa = new int[3];
        double rata; 
        int mtk, ipas, dspro;
        
        for (int i = 0; i < siswa.length; i++){
            System.out.println("\nMasukan Nilai Siswa "+(i+1));
            System.out.print("Matematika: ");
            mtk = sc.nextInt();
            System.out.print("IPAS: ");
            ipas = sc.nextInt();
            System.out.print("Daspro: ");
            dspro = sc.nextInt();
            int total = ipas+dspro+mtk;
            rata = total / 3;
            System.out.println("Rata rata nilai siswa " + (i+1)+": " + rata);
            System.out.println("=================");
        }
    }
}