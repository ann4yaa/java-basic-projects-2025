/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum13_hagia;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class tugas4_no4 {
    public static void main(String [] args){
        Scanner s = new Scanner(System.in);
        int n;
        System.out.print("Masukan Jumlah Array: ");
        n = s.nextInt();
        int [] array = new int[n];
        for (int i = 0; i<n; i++){
            System.out.print("Masukan array ke- "+i+": ");
            array[i] = s.nextInt();
        }
        for (int i = 0; i<n; i++){
            if (array[i] %2 == 0){
                System.out.println("Array ke-"+i+" adalah: Genap");
            } else {
                System.out.println("Array ke-"+i+" adalah: Ganjil");
            }
        }
    }
}
