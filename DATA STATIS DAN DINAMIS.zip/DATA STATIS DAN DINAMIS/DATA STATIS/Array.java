/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package latihansndr;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class Array {
    public static void main(String [] args){
        Scanner s = new Scanner(System.in);
        double nT, nR, rR;
        System.out.print("Masukan Jumlah Siswa: ");
        int sis = s.nextInt();
        
        System.out.print("Masukan Jumlah Mapel: ");
        int mapel = s.nextInt();
        
        int [] siswa = new int[sis];
        for (int i = 0; i < sis; i++){
            System.out.println("Nilai Siswa ke-"+(i+1));
            int [] nilai = new int[mapel];
            for (int n = 0; n < mapel; n++){
            System.out.println("Masukan Nilai ke-"+(n+1)+": ");
            nilai[n] = s.nextInt();
            }
            if (nilai[n] > 75){
                System.out.println(nilai[n]);
            } else if ( nilai[n] < 75){
                System.out.println(nilai[n]);
            }
            rR = nilai[n] / siswa[sis];
            System.out.println("Rata-rata: "+rR);
        }
    }
}
