/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package La;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class array2d {
    public static void main(String [] args){
        Scanner s = new Scanner(System.in);
        System.out.print("Masukan Jumlah Siswa: ");
        int jS = s.nextInt();
        System.out.print("Masukan Jumlah Mapel: ");
        int jM = s.nextInt();
        int [][] nilai = new int[jS][jM];
        for(int i = 0; i<jS; i++){
            System.out.println("== Data Siswa ke-"+(i+1)+" ==");
            for(int j = 0; j<jM; j++){
                System.out.print("Nilai ke-"+(j+1)+": ");
                nilai[i][j] = s.nextInt();
            }
        }
        for(int i = 0; i<jS; i++){
            System.out.println("=== Data Siswa Ke-"+(i+1));
            int total = 0;
            for(int j = 0; j<jM; j++){
                System.out.print(nilai[i][j]+" ");
                total += nilai[i][j];
            }
            double rata = (double) total / jM;
            System.out.println("Rata rata siswa ke-"+(i+1)+": "+rata);
        }
    }
}
