/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum13_hagia;
import java.util.Scanner;
/**
 *
 * @author USER
 */
public class Tugas4_no3 {
    public static void main(String [] args){
        Scanner s = new Scanner(System.in);
        int n, max ;
        System.out.print("Masukan jumlah array: ");
        n = s.nextInt();
        int [] array = new int [n];
        
        for (int i = 0; i<n; i++){
            System.out.print("Masukkan elemen array ke- "+i+":");
            array[i] = s.nextInt();
        } 
        max = array[0];
        for (int i = 0; i<n; i++){
            if (array[i] > max)
                max = array[i];
        }
        System.out.println("Elemen terbesar: "+ max);
    }
}