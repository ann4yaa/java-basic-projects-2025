package praktikum13_hagia;
import java.util.Scanner;
public class Aritmatika_Array {
    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       
       int [] nilaiMHS = new int[10];
       double rata;
       double total = 0;
               
       for (int i = 0; i <nilaiMHS.length; i++){
           System.out.print("Masukan nilai Mahasiswa ke-" + (i+1) + ":");
           nilaiMHS[i] = sc.nextInt();
       }
       for (int i = 0; i<nilaiMHS.length; i++){
           total += nilaiMHS[i];
       }
       rata = total/nilaiMHS.length;
       System.out.println("Nilai rata-rata kelas = " + rata);
    }
}