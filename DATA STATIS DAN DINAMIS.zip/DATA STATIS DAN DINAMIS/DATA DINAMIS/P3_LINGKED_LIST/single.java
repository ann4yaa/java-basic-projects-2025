/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas1;

/**
 *
 * @author USER
 */
public class single {
    Node head;
    Node tail;
    public void insertBefore(int key, int input){
        Node ndInput = new Node (input, null);
        Node temp = head;
        do {
            if (temp.data == key){
                ndInput.next = temp.next;
                if(ndInput.next == null)tail = ndInput;
                break;
            }
            temp = temp.next;
        } while (temp != null);
    }
    public boolean isEmpty(){
        return head == null;
    }
    public void print(){
        if (!isEmpty()){
            Node tmp = head;
            System.out.print("Isi Lingked List:\t");
            while (tmp != null){
                System.out.println("");
            } 
        }else {
                System.out.println("Linked list kosong");
        }
    }
}