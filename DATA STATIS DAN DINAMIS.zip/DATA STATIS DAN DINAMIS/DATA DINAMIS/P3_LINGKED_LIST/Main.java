/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas1;

/**
 *
 * @author USER
 */
public class Main {
    public static void main(String [] args) throws Exception{
        single singLL = new single();
        
        singLL.print();
        singLL.insertBefore(98, 78);
    }
}