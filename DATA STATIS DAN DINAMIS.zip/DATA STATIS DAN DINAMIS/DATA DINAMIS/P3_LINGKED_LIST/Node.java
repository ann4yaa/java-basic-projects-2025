/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas1;

/**
 *
 * @author USER
 */
public class Node {
    int data;
    Node next;
    public Node(int nilai, Node selanjutnya){
        this.data = nilai;
        this.next = selanjutnya;
    }
}
