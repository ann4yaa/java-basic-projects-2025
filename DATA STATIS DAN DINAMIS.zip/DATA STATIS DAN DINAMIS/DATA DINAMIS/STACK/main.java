/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package stack;

/**
 *
 * @author USER
 */
public class main {
    public static void main(String [] args){
        Stack stk = new Stack(5);
        
        stk.push(15);
        stk.push(27);
        stk.push(13);
        stk.print();
        stk.push(11);
        stk.push(34);
        stk.pop();
        stk.peek();
        stk.print();
    }
}