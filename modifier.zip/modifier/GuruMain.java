/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modifier;

/**
 *
 * @author USER
 */
public class GuruMain {
    public static void main(String[] args){
        Guru g = new Guru();
        g.nama = "Venny";
        g.setNip(123456789);
        g.bidang = "TIK";
        g.tampilData();
    }
}
