/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package modifier;

/**
 *
 * @author USER
 */
public class Siswa {

    public String nama;
    private int nis;
    protected String jurusan;
    String kelas;
    
    //Method setter
    void setNis (int nis){
        this.nis = nis;
    }
    //Method getter
    public int getNis (){
        return this.nis;
    }
    public void tampilData(){
        System.out.println("Nama : " + nama);
        System.out.println("NIS : " + nis);
        System.out.println("Jurusan: " + jurusan);
        System.out.println("Kelas: " + kelas);
    }
}