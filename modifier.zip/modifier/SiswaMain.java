/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modifier;
/**
 *
 * @author USER
 */
public class SiswaMain {
    public static void main(String[] args){
        //Penetapan objek
        Siswa s = new Siswa();
        s.nama = "Hagia";
        s.setNis(1234);
        s.jurusan = "RPL";
        s.kelas = "1RPB";
        
        s.tampilData();
    }
}
