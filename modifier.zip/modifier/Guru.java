/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modifier;

/**
 *
 * @author USER
 */
public class Guru {
    public String nama;
    private int nip;
    String bidang;
    
    //Method setter
    void setNip (int nip){
        this.nip = nip;
    }
    //Method getter
    public int getNip (){
        return this.nip;
    }
    public void tampilData(){
        System.out.println("Nama Guru: " + nama);
        System.out.println("NIP: "+ nip);
        System.out.println("Bidang: "+ bidang);
    }
}
